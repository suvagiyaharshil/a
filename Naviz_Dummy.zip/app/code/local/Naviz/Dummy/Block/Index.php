<?php   
class Naviz_Dummy_Block_Index extends Mage_Core_Block_Template{   





}