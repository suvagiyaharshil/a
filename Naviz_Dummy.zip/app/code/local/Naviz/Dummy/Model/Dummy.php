<?php

class Naviz_Dummy_Model_Dummy extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("dummy/dummy");

    }

}
	 