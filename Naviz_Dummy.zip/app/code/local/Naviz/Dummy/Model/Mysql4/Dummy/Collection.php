<?php
    class Naviz_Dummy_Model_Mysql4_Dummy_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("dummy/dummy");
		}

		

    }
	 