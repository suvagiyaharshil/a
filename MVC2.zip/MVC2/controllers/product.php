<?php
class Product extends BaseController {
    /**
     * @author Tatvasoft
     * Default method of Home controller and load header,main content,footer view.
     * 	 
     */
    public function index($id) {
        $size=array();
        $color=array();
        $this->load_model('ProductList');
        $size = $this->productlist->showSize();
        $color = $this->productlist->setColor();
        //$products['item'] = $this->productlist->getProductDetail($id);
//        echo '<pre>';
//        print_r($color);
//        exit();
        $this->load_view('header');
        $this->load_view('product',array('size'=>$size,'color'=>$color));
        if (isset($_POST['news'])) {
            $this->load_model('NewsModel');
            $this->newsmodel->newsInsert($_POST);
        }
        $this->load_view('footer');
    }

    public function detail($id) {
        $this->load_model("ProductList");
        $product['item_detail'] = $this->productlist->getitem($id);
        $product['item_size'] = $this->productlist->item_size($id);
        $product['item_review'] = $this->productlist->review_data($id);
        $product['image_slider'] = $this->productlist->slider_image($id);
        $this->load_view('header');
        $this->load_view('product_detail', $product);
        if (isset($_POST['news'])) {
            $this->load_model('NewsModel');
            $this->newsmodel->newsInsert($_POST);
        }
        $this->load_view('footer');
    }

    public function addwislist() {
        $this->load_model("ProductList");
        $id = $_POST['id'];
        $product = $this->productlist->addtowishlist($id);
        if ($product == true) {
            echo json_encode(array('status' => 1, 'msg' => 'success'));
        } else {
            echo json_encode(array('status' => 2, 'msg' => 'falls'));
        }
    }
    public function addreview(){
        $this->load_model("ProductList");
        $rating=$_POST['rating'];
        $comment=$_POST['coment'];
        $item_id=$_POST['itemid'];
        $user_id=$_SESSION['user_id'];
        $addreviewreuslt=$this->productlist->addtoreview($rating,$comment,$item_id,$user_id);
        if($addreviewreuslt==true){
            //echo json_encode(array($addreviewreuslt));
        }
        else{
            echo json_encode(array('status' => 2, 'msg' => 'you already insert review in this product'));   
        }
    }
    public function getsize(){
        $id=$_POST['id'];
        $size=$_POST['size'];
        
        $this->load_model("ProductList");
        $getitemwithsize=$this->productlist->getitemwithsize($id,$size);
        //echo "<pre>";print_r($getitemwithsize);exit();
        $item="";
        foreach ($getitemwithsize as $value) {
             ?><script>
                $("#more_product_btn").hide();
                $("#no_more_data").html("Sorry No More Products....");
            </script> 
            <?php
            $item="<div class='col-sm-4 img1'><div class='bg'><a href=".SITE_URL."product/detail/".$value['id']."><img src=".ASSETS_URL."/image/". $value['item_images_url'].".jpg"." class='img-responsive mainimg'></a><center class='product_button'><a href=".SITE_URL."cart/addtocart/".$value['i_o_id']."><button type='button' class='btn btn-default middle'>ADD TO CART </button> </a> </center>
            </div><div class='caption'><article  class='artical_text'>".$value['name']."<br/><b  class='prize_color'>$".$value['price']."</b><br><b>Color:".$value['value']."</b></article></div></div>";
        echo ($item);
        }
    }
    
    public function getcolor(){
        $id=$_POST['id'];
        $color=$_POST['color'];
        $this->load_model("ProductList");
        $getitemwithcolor=$this->productlist->getitemwithcolor($id,$color);

        $item="";
        foreach ($getitemwithcolor as $value) {
            ?><script>
                $("#more_product_btn").hide();
                $("#no_more_data").html("Sorry No More Products....");
            </script> 
            <?php
            $item="<div class='col-sm-4 img1'><div class='bg'><a href=".SITE_URL."product/detail/".$value['id']."><img src=".ASSETS_URL."/image/". $value['item_images_url'].".jpg"." class='img-responsive mainimg'></a><center class='product_button'><a href=".SITE_URL."cart/addtocart/".$value['i_o_id']."><button type='button' class='btn btn-default middle'>ADD TO CART </button> </a> </center>
            </div><div class='caption'><article  class='artical_text'>".$value['name']."<br/><b  class='prize_color'>$".$value['price']."</b><br><b>Size:".$value['value']."</b></article></div></div>";
        echo ($item);
        
        }
    }
}
