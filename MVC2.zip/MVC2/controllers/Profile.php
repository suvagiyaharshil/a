<?php

class Profile extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Home controller and load header,main content,footer view.
     * 	 
     */
    /* public function test(){
      echo "test";
      exit();
      } */
    public function index() {
        $this->load_model("ProfileModel");
        $userinfo = $this->profilemodel->getUserInfo();
        $data['value'] = $userinfo->fetch_assoc();
        $shiping_set = $data['value']['shipping_add_id'];
        $data['country_shoping'] = $this->profilemodel->country_shoping();
        if (isset($shiping_set)) {
            $data['address'] = $this->profilemodel->getshippingaddress($shiping_set);
            $country_id = $data['address'][0]['country_id'];
            $data['state'] = $this->profilemodel->getshipingstate($country_id);
        }
        /* echo "<pre>";
          print_r($data['country_shoping']);
          exit(); */
        $biling_set = $data['value']['billing_add_id'];
        $data['country_biling'] = $this->profilemodel->country_biling();
        if (isset($biling_set)) {
            $data['address_biling'] = $this->profilemodel->getbilingaddress($biling_set);
            $country_id = $data['address_biling'][0]['country_id'];
            $data['state_set_biling'] = $this->profilemodel->getbilingstate($country_id);
        }
        $this->load_view('header');
        $this->load_view('profile', $data);
        if (isset($_POST['news'])) {
            $this->load_model('NewsModel');
            $this->newsmodel->newsInsert($_POST);
        }
        $this->load_view('footer');
    }

    public function state_shoping() {
        $this->load_model("ProfileModel");
        $getstate = $this->profilemodel->insert_state_shoping($_POST);
        echo json_encode($getstate);
    }

    public function state_biling() {
        $this->load_model("ProfileModel");
        $getstate = $this->profilemodel->insert_state_biling($_POST);
        echo json_encode($getstate);
    }

    public function update_data() {
        $previos_page = $_SERVER["HTTP_REFERER"];
        $this->load_model("ProfileModel");
        $userinfo = $this->profilemodel->getUserInfo();
        $data['value'] = $userinfo->fetch_assoc();
        $shiping_set = $data['value']['shipping_add_id'];
        $biling_set = $data['value']['billing_add_id'];
        $updatedata = $this->profilemodel->update_user_info($_POST, $shiping_set, $biling_set);
        if ($updatedata == true) {
            echo "<script>window.location.replace(\"$previos_page\");</script>";
        } else {
            echo "<script>alert('email are alredy register');window.location.replace(\"$previos_page\");</script>";
        }
    }

    public function change_password() {
        $this->load_view('header');
        $this->load_model("ProfileModel");
        $this->profilemodel->change_Password($_POST);
        $this->load_view('change_password');
        if(isset($_POST['news'])) {
        $this->load_model('NewsModel');    
        $this->newsmodel->newsInsert($_POST);    
        }
        $this->load_view('footer');
    }

}
