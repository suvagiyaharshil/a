<?php

class Register extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Register Controller
     * @params userdata 
     * @return validation user and do login process 
     */
    public function index() {
        $validationErrors = array();

        if (isset($_POST['register_submit'])) {

            $this->load_model("RegisterModel");

            if ($this->registermodel->insert($_POST)) {

                $this->load_model("LoginModel");

                if ($this->loginmodel->authenticate($this->registermodel->data['email'], $this->registermodel->data['password'])) {
                    $this->redirect('home/index');
                }
            } else {
                // insert fail due to some validation errors
                $validationErrors = $this->registermodel->getErrors();
            }
        }

        $this->load_view('header');
        $this->load_view('user/register', array('validationErrors' => $validationErrors));
        //$this->load_ajax_view('employee/index', $viewData); // call this method in case you are using ajax call request
        if (isset($_POST['news'])) {
            $this->load_model('NewsModel');
            $this->newsmodel->newsInsert($_POST);
        }
        $this->load_view('footer');
    }

    public function emailvalidate() {
        $this->load_model("RegisterModel");
        if ($this->registermodel->checkEmailExist($_POST['email'])) {
            echo "Email-id already registered.";
        } else {
            
        }
    }
    public function uservalidate() {
        $this->load_model("RegisterModel");
        if ($this->registermodel->checkUsernameExist($_POST['username'])) {
            echo "Username already registered.";
            exit;
        } else {
        }
    }
}
