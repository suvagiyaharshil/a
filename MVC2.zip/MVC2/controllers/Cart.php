<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Cart extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Home controller and load header,main content,footer view.
     * 	 
     */
    public function index() {
        if(!checkIfLogin()){
            $this->redirect('home/index');
        }
        else{
        $this->load_view('header');
        $this->load_view('cart');
//                $this->load_model("ProductList");
//        $getItemData=$this->productlist->getvaritonid(1);
//        
//                    $qty=array('qty'=>5);
//                    $size=array('size'=>'S');
//        var_dump(array_merge($getItemData,$qty,$size));
//        die();
        if (isset($_POST['news'])) {
            $this->load_model('NewsModel');
            $this->newsmodel->newsInsert($_POST);
        }
        $this->load_view('footer');
    }
    }
//    public function addtocart($id) {
//        
//        $prevois = $_SERVER['HTTP_REFERER'];
//        if (checkIfLogin()) {
//            $this->load_model("ProductList");
//            $getItemData = $this->productlist->getitemdata($id);
//            foreach ($getItemData as $product) {    
//            }
//            echo "<pre>";print_r($product);echo "exit";exit();
//            if (empty($_SESSION["cart"])) {
//                $i = 1;
//                $qty = array('qty' => 1);
//                $_SESSION['cart'][$i++] = array_merge($product, $qty);
//            } else {
//                $flag = 0;
//                if ($flag == 0) {
//                    foreach ($_SESSION['cart'] as $i => $value) {    
//                    }
//                    $qty = array('qty' => 1);
//                    $_SESSION['cart'][++$i] = array_merge($product, $qty);
//                } else {
//                    ++$_SESSION["cart"][$idIndex]['qty'];
//                }
//            }
//            echo "<script>";
//            echo "window.location.replace(\"$prevois\")";
//            echo "</script>";
//            echo "<pre>";print_r($_SESSION["cart"]);exit();
//        } else {
//            echo "<script>";
//            echo "alert('Please log in to add product into cart.');";
//            echo "window.location.replace(\"$prevois\")";
//            echo "</script>";
//        }
//    }
    public function addtocart() {
        die("ffffffff");
        $size1 = $_POST['size'];
        $qty1 = $_POST['qty'];
        $id = $_POST['id'];
        $prevois = $_SERVER['HTTP_REFERER'];

        if (checkIfLogin()) {
            $this->load_model("ProductList");
            $getItemData = $this->productlist->getvaritonid($id);
            if (empty($_SESSION["cart"])) {
                $i = 0;
                $qty = array('qty' => $qty1);
                $size = array('size' => $size1);
                $_SESSION['cart'][$i++] = array_merge($getItemData, $qty, $size);
            } else {
                $flag = 0;
                $idIndex = 0;
                $size = array('size' => $size1);
                foreach ($_SESSION["cart"] as $index => $indata) {
                    if ($indata[0] == $id) {
                        $flag = 1;
                        $idIndex = $index;
                        break;
                    }
                }
                if ($flag == 0) {
                    foreach ($_SESSION['cart'] as $i => $value) {
                        
                    }
                    $qty = array('qty' => $qty1);
                    $_SESSION['cart'][++$i] = array_merge($getItemData, $qty, $size);
                } else {
                    $_SESSION["cart"][$idIndex]['qty'] = $_SESSION["cart"][$idIndex]['qty'] + $qty1;
                }
            }

            echo "<script>";
            echo "window.location.replace(\"$prevois\")";
            echo "</script>";
        } else {
            echo "<script>";
            echo "alert('Please log in to add product into cart.');";
            echo "window.location.replace(\"$prevois\")";
            echo "</script>";
            
        }
    }

    public function deletecart($id) {
        $previos_page = $_SERVER["HTTP_REFERER"];
        if (isset($id)) {
            foreach ($_SESSION['cart'] as $i => $usetvalue) {
                if ($usetvalue[0][0] == $id) {
                    unset($_SESSION['cart'][$i]);
                }
            }
        } else {
            unset($_SESSION['cart']);
        }
        echo "<script>window.location.replace(\"$previos_page\");</script>";
    }

    public function updatecart($data) {
        $previos_page = $_SERVER["HTTP_REFERER"];
        $qty = $_POST['qty'];
        $id = $_POST['id'];
//         echo "$id";
//          echo "$qty";          exit();

        foreach ($_SESSION['cart'] as $index => $indata) {
            if ($indata[0][0] == $id) {
                $flag = 1;
                $idIndex = $index;
                break;
            }
        }
        if ($flag == 1) {
            foreach ($_SESSION['cart'] as $i => $value) {
                $_SESSION['cart'][$idIndex]['qty'] = $qty;
            }
        }
        else {die("flag not set");}
//        echo "<pre>";
//        print_r($_SESSION['cart']);
        echo "<script>window.location.replace(\"$previos_page\");</script>";
    }

}
