<?php
$assets_url = ASSETS_URL;
?>
<!-- Footer Start -->
<footer class="footer container-fluid" >

    <div class="row">
        <div class="col-sm-12 form">
            <p style="color:#b2dba1;font-size: 12px;padding: 1%;margin: -1%;padding-left: 11%;display: none;" id="footer_news" class="footer_news">Thank you for your subscription</p>
           
            <form class="form-inline footer_bg" method="post" action="">
                <div class="form-group">
                    <label for="email" class="label_text">Substribe for Newsletter</label>
                    <input type="email" class="form-control" style="color: white;" name="email" id="email" placeholder="Enter Your E-mail Address">
                </div>
                <button type="submit" name="news" id="footer_news_button" class="btn btn-default footer_button">Sign Up</button>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <ul class="container">
                <li><a href="home" class="form_color">Home</a></li>
                <li><a href="about" class="form_color">About us</a></li>
                <li><a href="register" class="form_color">Register</a></li>
                <li><a href="contact" class="form_color">Contact us</a></li>
            </ul>
        </div>
    </div>
    <hr>
    <div class="row">
        <center>
            <article class="footer_copyright"> 
                &copy;2017eShopper online store.All rights reserved
            </article><br/><br/>   
        </center>
    </div>
</footer>
<!--<script type="text/javascript">
$("#footer_news_button").click(function() {
  $("#footer_news").show();
 });
</script>-->
<?php if (!checkIfLogin()) { ?>
    <div class="popup-outer">
        <div class="modal fade <?php //echo (isset($login_error_msg) ? 'in' :'');      ?>" id="Login-popup" tabindex="-1" role="dialog" aria-hidden="true" style="display:<?php echo (isset($login_error_msg) ? 'block' : ''); ?>">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <h2>eShopper Login</h2>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-dismissible alert-danger login_alert" role="alert" style="display:none">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                            <span class="login_msg"></span>
                        </div>
                        <form class="loginform" action="" method="post" name="loginform" id="login_form">
                            <div class="form-group <?php ////echo (isset($login_error_msg) ? 'validation-error' : '');      ?>">
                                <label class="form-label">Username</label>
                                <input type="text" class="form-control" placeholder="Enter your Username" name="login[email]">
                            </div>
                            <div class="form-group <?php //echo (isset($login_error_msg) ? 'validation-error' : '');      ?>">
                                <label class="form-label">Password</label>
                                <input type="password" class="form-control" placeholder="Enter your Password" name="login[password]">
                            </div>
                            <div class="form-group clearfix login-options">
                                <button type="submit" class="btn-secondary" id="login_button">Login</button>
                                <p>Not a Member? <a href="<?php echo SITE_URL . 'register'; ?>" title="Register">Register</a></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
</div>


<script type="text/javascript" src="<?php echo $assets_url; ?>/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo $assets_url; ?>/js/owl.carousel.js"></script>
<script type="text/javascript" src="<?php echo $assets_url; ?>/js/jssor.slider-26.9.0.min.js"></script>
<script type="text/javascript" src="<?php echo $assets_url; ?>/js/script.js"></script>
</body>
</html>