<?php
$assets_url = SITE_URL . '/public/';
?>
<div class="wap container-fluid">
        </div>
        <img src="<?php echo $assets_url; ?>image/inner-banner.jpg" alt="Banner" class="img-responsive banner"/>
        <div class="container-fluid mediabg">
            <div class="container">
                <h2 class="about">Register</h2>
                <div class="row">
                    <ol class="breadcrumb mediabg">
                        <li class="breadcrumb-item"><a href="home" class="mediabg_color">Home</a></li>
                        <li class="breadcrumb-item"><a href="register" class="active_breadcrumb">Register</a></li>
                    </ol>
                </div>
            </div>
        </div>
        
        <div class="container">
            <h2 class="reg_h2">New Customers</h2>
            <p class="reg_p">By Creating an account with our store, you will be able to move through the checkout process faster, store multiple shopping addresses, view and track your orders in your orders in your account and more</p>
            <?php if (isset($_SESSION['msg'])) { ?>
            <div class="container shopping-wrap">
                <div class="alert alert-dismissible alert-success" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                    <i><img src="<?php echo $assets_url; ?>images/success.svg" alt="success"></i> <span> <?php echo $_SESSION['msg']; ?></span>
                </div>
            </div>
            <?php
            unset($_SESSION['msg']);
        }
        ?>
            <form name="register" action=""  method="post" class="reg_form">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group reg_field <?php echo (isset($validationErrors['username'])) ? 'validation-error' : ''; ?>">
                            Username
                            <input type="text" class="form-control" name="username" id="username" placeholder="Please enter user name">
                            <p id="username_error1"><?php echo (isset($validationErrors['username'])) ? $validationErrors['username'] : ''; ?></p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group reg_field">
                            Gender<br/>
                            <div class="radio-inline reg_radio_input">
                                <input type="radio" name="gender" id="genmale" value="0" checked> Male
                            </div>
                            <div class="radio-inline reg_radio_input">
                                <input type="radio" name="gender" id="genfemale" value="1"> Female
                            </div>
                            <p id="gender_error"><?php echo (isset($validationErrors['gender'])) ? $validationErrors['gender'] : ''; ?></p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group reg_field">
                            Password
                            <input type="password" class="form-control" name="password" id="password" placeholder="Please enter Password">
                            <p id="passwordd_error"><?php echo (isset($validationErrors['password'])) ? $validationErrors['password'] : ''; ?></p>
                        </div>
                        <div class="form-group reg_field">
                            Confirm Password
                            <input type="password" class="form-control" id="confirm_password" placeholder="Please Re-enter Password">
                            <p id="confirm_password_error"></p>
                        </div>
                    </div>


                    <div class="col-sm-6">
                        <div class="form-group reg_field">
                            First Name
                            <input type="text" class="form-control" name="firstname" id="firstname" placeholder="Please enter user name">
                            <p id="firstname_error"><?php echo (isset($validationErrors['firstname'])) ? $validationErrors['firstname'] : ''; ?></p>
                        </div>
                        <div class="form-group reg_field">
                            Last Name
                            <input type="text" class="form-control" name="lastname" id="lastname" placeholder="Please enter last name">
                            <p id="lastname_error"><?php echo (isset($validationErrors['lastname'])) ? $validationErrors['lastname'] : ''; ?></p>
                        </div>

                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">

                        <div class="form-group reg_field">
                            Mobile No.
                            <input type="text" class="form-control" name="mobile" id="mobile" placeholder="Please enter Mobile No.">
                            <p id="mobile_error"><?php echo (isset($validationErrors['mobile'])) ? $validationErrors['mobile'] : ''; ?></p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group reg_field">
                            Phone
                            <input type="text" class="form-control" name="phone" id="phone" placeholder="Please enter your phone">
                            <p id="phone_error"><?php echo (isset($validationErrors['phone'])) ? $validationErrors['phone'] : ''; ?></p>
                        </div>
                    </div>
                </div>    

                <div class="row">
                    <div class="col-sm-6">
                        Interests
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="c1" id="all" name="c" onclick="return selectAll();" >

                            select all

                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="c2" id="option1" name="c" onclick="return otherClick();">

                            Option 1

                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="c3" id="option2" name="c" onclick="return otherClick();">

                            Option 2

                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="c4" id="option3" name="c" onclick="return otherClick();">

                            Option 3

                        </div>
                        <div class="form-check reg_chtxt">
                            <input class="form-check-input" type="checkbox" value="c5" id="other" name="c" onclick="return textBoxhide();">
                            Other
                            <input type="text" style="visibility :hidden;" class="form-control reg_chtxt" name="other_button" id="togglee"> 
                            <p id="other_error"></p>
                        </div>
                        <p id="checkbox_error"><?php echo (isset($validationErrors['c'])) ? $validationErrors['c'] : ''; ?></p>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group reg_field">
                            Email
                            <input type="text" class="form-control" name="email" id="email" placeholder="Please enter valid e-mail">
                            <p id="email_error"><?php echo (isset($validationErrors['email'])) ? $validationErrors['email'] : ''; ?>
                                </p>

                        </div> 
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-check">
                            <input name="term" class="form-check-input" type="checkbox" id="term" name="is_agree">
                            I Agree With Terms & Conditions.
                            <p id="term_error"><?php echo (isset($validationErrors['is_agree'])) ? $validationErrors['is_agree'] : ''; ?></p>    
                        </div>    
                    </div>   
                    <div class="col-sm-6">
                        <button type="reset" class="btn btn-default reg_button reg_clear  cart_update_button" onclick="return clear();" name="clear">Clear</button> 
                        <button type="submit" class="btn btn-default reg_button reg_submit" name="register_submit" id="register">Submit</button>
                    </div>    
                </div>    

            </form>           
        </div>
        <button type="button" class="top_arrow" id="top" onclick="gototop();"><object type="image/svg+xml" data="<?php echo $assets_url; ?>image/up-arrow-white.svg" height="15px" width="15px">
            </object></button>
    </body>
</html>