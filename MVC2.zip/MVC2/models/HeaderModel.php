<?php

class HeaderModel extends basemodel {
    /* Table which is mapped to current model */

    private $_table = 'category';

    function getParCategories() {
        $query = "SELECT id, name FROM " . $this->_table . " WHERE parent_id = '0'";
        return $this->_db->query($query);
    }
    
    function getSubCategories($id) {
        $query = "SELECT id,name FROM " . $this->_table . " WHERE parent_id = '$id' ";
        return $this->_db->query($query);
    }  
}

?>
