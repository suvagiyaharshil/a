<?php

$assets_url = ASSETS_URL;

class ProfileModel extends basemodel {
    /* Table which is mapped to current model */
    function getUserInfo() {
        $query = "select u.username,u.password,u.email,u.gender,u.firstname,u.lastname,u.mobile_number,u.phone_number,u.shipping_add_id,u.billing_add_id
  		from user u
  		where u.id='" . $_SESSION['user_id'] . "'";
        return $this->_db->query($query);
    }

    function country_shoping() {
        $query = "select * from country";
        return $this->getResultArray($this->_db->query($query));
    }

    function getshippingaddress($shiping_set) {
        
        if (isset($shiping_set)) {
            $query = "select ad.id,ad.street,ad.city,ad.state_id,s.name,c.name,s.country_id 
          from address ad 
          left join state s on ad.state_id=s.id
          left join country c on s.country_id=c.id  
          where ad.id=$shiping_set";
            
            
            return $this->getResultArray($this->_db->query($query));
        }
    }

    function getbilingaddress($biling_set) {
       
        if (isset($biling_set)) {
            $query = "select ad.id,ad.street,ad.city,ad.state_id,s.name,c.name,s.country_id 
          from address ad 
          left join state s on ad.state_id=s.id
          left join country c on s.country_id=c.id  
          where ad.id=$biling_set";
            
            return $this->getResultArray($this->_db->query($query));
        }
    }

    function country_biling() {
        $query = "select * from country";
        return $this->getResultArray($this->_db->query($query));
    }

    function insert_state_shoping() {
        $id = $_POST['id'];
         
        $query = "select id,name from state where country_id=$id";
        return $this->getResultArray($this->_db->query($query));
    }

    function getshipingstate($country_id) {
        $query = "select id,name from state where country_id=$country_id";
        return $this->getResultArray($this->_db->query($query));
    }

    function insert_state_biling() {
        $id = $_POST['id'];
        $query = "select id,name from state where country_id=$id";
        return $this->getResultArray($this->_db->query($query));
    }

    function getbilingstate($country_id) {
        $query = "select id,name from state where country_id=$country_id";
        return $this->getResultArray($this->_db->query($query));
    }

    function update_user_info($data, $shiping_set, $biling_set) {
        $userName = $data['username'];
        $gender = $data['gender'];
        $email = $data['email'];
        $firstName = $data['firstname'];
        $lastName = $data['lastname'];
        $mobileNo = $data['mobile'];
        $phone = $data['phone'];
        $street_sh = $data['street'];
        $city_sh = $data['city'];
        $state_sh = $data['state'];
        $street_bil = $data['street2'];
        $city_bil = $data['city2'];
        $state_bil = $data['state2'];
        $query = "select * from user where email='$email' and username!='$userName'";
        
        if ($this->_db->query($query)->num_rows == 0) {
            if (is_null($shiping_set)) {
                $query = "insert into address(street,city,state_id)
          values('$street_sh','$city_sh',$state_sh)";
                if ($this->_db->query($query) == true) {
                    $shi_id = mysqli_insert_id($this->_db);
                    $query1 = "update user 
             set shipping_add_id=$shi_id
             where username='$userName'";
                    $this->_db->query($query1);
                }
            } else {

                $query = "update address 
             set street='$street_sh',city='$city_sh',state_id=$state_sh
             where id=$shiping_set";
                $this->_db->query($query);
            }
            
            if (is_null($biling_set)) {
                $query = "insert into address(street,city,state_id)
          values('$street_bil','$city_bil',$state_bil)";
                if ($this->_db->query($query) == true) {
                    $shi_id = mysqli_insert_id($this->_db);
                    $query1 = "update user 
             set billing_add_id=$shi_id
             where username='$userName'";
                    $this->_db->query($query1);
                }
            } else {
                //echo $state_bil; exit();
                $query = "update address 
             set street='$street_bil',city='$city_bil',state_id=$state_bil
             where id=$biling_set";
                $this->_db->query($query);
            }
            $query = "update user 
         set gender='$gender',email='$email',firstname='$firstName',lastname='$lastName',mobile_number='$mobileNo',phone_number='$phone'
         where username='$userName'";

            if ($this->_db->query($query) == TRUE) {
                return true;
            }
        } else {
            return false;
        }
    }

    function change_Password($data) {
        $newpassword = ($data['newpassword']);
        $renewpassword = ($data['renewpassword']);
        $username = ($data['username']);
        $newpassword = md5($newpassword);
        $sql = "update user 
		         set password='$newpassword'
		         where id='$username'";
        $this->_db->query($sql);
        header("location:profile");
    }
}
?>