<?php

$assets_url = ASSETS_URL;

class ProductList extends basemodel {
    /* Table which is mapped to current model */
    private $_table = 'item';
    function getProductDetail($id) {
        $query = "select i.name,i.price,i.id,i.category_id,i.is_trending,im.item_images_url,at_op.value,i_o.id as i_o_id from item i
		  left join item_images im on im.item_id=i.id 
		  left join item_options i_o on i_o.item_id=i.id
		  left join attributes_options at_op on at_op.id=i_o.ao_id
		  where im.is_primary=1 and i.category_id=$id";
        return $result = $this->_db->query($query);
        //return $this->getResultArray($this->_db->query($query));
    }
    function showImg($limit) {
        
        $query = "select it.id,it.name,it.price,ii.item_images_url,ii.item_id,ii.is_primary from item_images ii, item it where it.id=ii.item_id and ii.is_primary = 1  LIMIT $limit ";
        //echo "<pre>";print_r($this->_db->query($query));exit();
        return $this->_db->query($query);
    }
    function home_showImg($limit) {
        $query = "select it.id,it.name,it.price,ii.item_images_url,ii.item_id,ii.is_primary from item_images ii, item it where it.id=ii.item_id and ii.is_primary = 1 and it.is_trending=1 LIMIT $limit";
        
        return $this->_db->query($query);
    }
    
    public function getitem($id) {
        $query = "select i.name,i.price,i.qty,i.id,i.is_trending,i.sku,i.category_id,i.color_id,i.short_desc,i.description,i.delivery_desc,i.shipping_desc,i.sizeguide_desc,at.value,im.item_id,im.item_images_url from item i
		  left join item_images im on im.item_id=i.id
		  left join attributes_options at on at.id=i.color_id 
		  where i.id=$id and is_primary=1";
        return $this->getResultArray($this->_db->query($query));
    }
    public function item_size($id) {
        $query = "select at_op.value
		from item_options i_o
		left join attributes_options at_op on at_op.id=i_o.ao_id
		where at_op.attribute_id=1 and i_o.item_id=$id";
        return $this->getResultArray($this->_db->query($query));
    }
    public function getitemwithsize($id,$size){
            //echo "<pre>";print_r($size);exit();
		$query="select 
		i.name,i.price,i.id,i.category_id,i.is_trending,im.item_images_url,at_op.value,i_o.id as i_o_id from item i 
		left join item_images im 
			on im.item_id=i.id 
		left join item_options i_o 
			on i_o.item_id=i.id 
		left join attributes_options at_op 
			on at_op.id=i_o.ao_id 
		where im.is_primary=1 and at_op.id=$size group by i.id
			";
                
		 return $this->getResultArray($this->_db->query($query));
	}
	public function getitemwithcolor($id,$color){
               
		$query="select 
		i.name,i.price,i.id,i.category_id,i.is_trending,im.item_images_url,at_op.value,i_o.id as i_o_id from item i 
		left join item_images im 
			on im.item_id=i.id 
		left join item_options i_o 
			on i_o.item_id=i.id 
		left join attributes_options at_op 
			on at_op.id=i.color_id
		where im.is_primary=1 and at_op.attribute_id=2 and at_op.value='$color' group by i.id";       
    return $this->getResultArray($this->_db->query($query));

	}
    public function addtowishlist($id) {
        // echo "hi";
        $user_id = $_SESSION['user_id'];
        $item_id = $id;
        $query = "select item_id,user_id from wishlist where item_id=$item_id and user_id=$user_id";

        if ($this->_db->query($query)->num_rows == 0) {
            $query = "insert into wishlist (item_id,user_id)
	 	values($item_id,$user_id)";
            $result = $this->_db->query($query);
            return true;
        } else {
            return false;
        }
    }

    public function addtoreview($rating, $comment, $item_id, $user_id) {
        $query = "select item_id,user_id from item_review where item_id=$item_id and user_id=$user_id";
        if ($this->_db->query($query)->num_rows == 0) {
            $query = "insert into item_review (user_id,item_id,review_text,ratings,review_date) values($user_id,$item_id,'$comment',$rating,now())";
            if ($this->_db->query($query) == true) {
                $query = "select DATE_FORMAT(ir.review_date, '%d-%m-%Y') as date,u.firstname 
	 			from item_review ir
				left join user u on u.id=ir.user_id
		 		where ir.item_id=".$item_id." 
		 		AND  ir.user_id=".$user_id." 
		 		ORDER BY ir.id DESC LIMIT 1";
                return $this->getResultArray($this->_db->query($query));
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    public function getvaritonid($id){
	$query="SELECT item.id, item_images_url, item.name, price, value 
                FROM item 
                INNER JOIN item_images ON item.id = item_images.item_id 
                INNER JOIN  attributes_options ON item.color_id = attributes_options.id 
                WHERE item.id = '".$id."' 
                GROUP BY item.id;";
        
    $result = $this->_db->query($query)->fetch_all();
    
    
//    foreach ($result as $value) {
//    	$varition_id=$value['id'];
//    }

//    $query1="SELECT i_o.id,i.name,i.qty,im.item_images_url,i.price,a_t.value,(SELECT a_t.value FROM item i
//     LEFT JOIN item_options i_o ON i_o.item_id=i.id 
//     LEFT JOIN attributes_options a_t ON i.color_id=a_t.id 
//              WHERE i.color_id=a_t.id AND i_o.id=$varition_id)  as color
//     FROM item_options i_o 
//     LEFT JOIN item i ON i_o.item_id=i.id 
//                    LEFT JOIN item_images im ON i.id=im.item_id 
//     LEFT JOIN attributes_options a_t ON i_o.ao_id= a_t.id
//     WHERE i_o.id=$varition_id AND im.is_primary=1";
//          echo "<pre>";
//        print_r($this->_db->query($query1));       
// exit();
     return $result;
    }
    public function review_data($id) {
        $query = "select * from item_review ir
				left join user u on u.id=ir.user_id
		 		where item_id=$id ORDER BY ir.id DESC";
        return $this->getResultArray($this->_db->query($query));
    }
    
    
    public function slider_image($id) {
        $query = "select * from item_images where item_id=$id";
        return $this->getResultArray($this->_db->query($query));
    }
    
    public function getitemdata($id) {
        $query = "SELECT i_o.id,i.name,i.qty,im.item_images_url,i.price,a_t.value,(SELECT a_t.value FROM item i
     LEFT JOIN item_options i_o ON i_o.item_id=i.id 
     LEFT JOIN attributes_options a_t ON i.color_id=a_t.id 
              WHERE i.color_id=a_t.id AND i_o.id=$id)  as color
     FROM item_options i_o 
     LEFT JOIN item i ON i_o.item_id=i.id 
                    LEFT JOIN item_images im ON i.id=im.item_id 
     LEFT JOIN attributes_options a_t ON i_o.ao_id= a_t.id
     WHERE i_o.id=$id AND im.is_primary=1";
//echo "<pre>";print_r($this->_db->query($query));echo "exit";exit();
        return $this->getResultArray($this->_db->query($query));
        /* } */
    }
    function setColor() {
        $query = "SELECT id, attribute_id, value FROM attributes_options WHERE attribute_id = 2";
        return $result = $this->_db->query($query);
    }

    function totalProductInColor($color_id) {
        $query = "select count(*) as total from item where color_id = $color_id ";
        return $result = $this->_db->query($query);
    }
    function totalProductInSize($size_id) {
        $query = "select count(*) as total from item where id in(select item_id from item_options where ao_id in (select id from attributes_options where id = $size_id))";
        return $result = $this->_db->query($query);
    }
    function showSize() {
        $query = "select * from attributes_options where attribute_id = 1";
        return $result = $this->_db->query($query);
    }
    function showImageIds($value) {
        $query = "select * from item_options where ao_id in ($value)";
        return $result = $this->_db->query($query);
    }
}
?>
