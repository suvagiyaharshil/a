<?php

class LoginModel extends basemodel {

    /**
     * @author Tatvasoft
     * check Authentication while login .
     * 
     * @params username/email and password 
     * @return true if valid user and false if invalid user .
     */
    public function authenticate($email, $password) {
        $this->email = trim(stripslashes(htmlspecialchars(strip_tags($email))));
        $this->password = md5($password);

        $sql = "SELECT id, firstname, email FROM user where username='" . $this->email . "' AND password = '" . $this->password . "'";
        $result = $this->_db->query($sql);
        $resultData = $result->fetch_assoc();

        if ($result->num_rows > 0) {

            $this->createSession($resultData);

            return true;
        } else {

            return false;
        }
    }

    /**
     * @author Tatvasoft
     * set user information in session.
     * 
     * @params User Information
     */
    public function createSession($userData) {
        $_SESSION['user_id'] = $userData['id'];
        $_SESSION['name'] = $userData['firstname'];
        $_SESSION['email'] = $userData['email'];
    }

}
