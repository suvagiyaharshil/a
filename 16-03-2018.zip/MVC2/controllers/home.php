<?php
class Home extends BaseController {
    public function index() {
       // $products = array(array());
        //$this->load_model('ProductList');
        //$products = $this->productlist->getProductDetail();
//        print_r($products);
        $this->load_view('header');
        $this->load_view('home');
        if (isset($_POST['news'])) {
            $this->load_model('NewsModel');
            $this->newsmodel->newsInsert($_POST);
        }
        $this->load_view('footer');
    }

    }
