<?php
class Product extends BaseController {
    public function index($id) {
        $size = array();
        $color = array();
        $this->load_model('ProductList');
        $size = $this->productlist->showSize();
        $color = $this->productlist->setColor();
        $price = $this->productlist->Price();
        //$products['item'] = $this->productlist->getProductDetail($id);
//        echo '<pre>';
//        print_r($color);
//        exit();
        $this->load_view('header');
        $this->load_view('product', array('size' => $size, 'color' => $color, 'price' => $price));
        if (isset($_POST['news'])) {
            $this->load_model('NewsModel');
            $this->newsmodel->newsInsert($_POST);
        }
        $this->load_view('footer');
    }

    public function detail($id) {
        $this->load_model("ProductList");
        $product['item_detail'] = $this->productlist->getitem($id);
        $product['item_size'] = $this->productlist->getsize($id);
        $product['item_review'] = $this->productlist->getreview($id);
        $product['image_slider'] = $this->productlist->slider_image($id);
        $this->load_view('header');
        $this->load_view('product_detail', $product);
        if (isset($_POST['news'])) {
            $this->load_model('NewsModel');
            $this->newsmodel->newsInsert($_POST);
        }
        $this->load_view('footer');
    }

    public function addwislist() {
        if (checkIfLogin()) {
            $this->load_model("ProductList");
            $id = $_POST['id'];
            $product = $this->productlist->addwishlist($id);
            if ($product == true) {
                echo "1";
            } else {
                echo "2";
            }
        } else {
            echo "3";
        }
    }

    public function addreview() {
        if (checkIfLogin()) {
            $this->load_model("ProductList");
            $rating = $_POST['rating'];
            $comment = $_POST['coment'];
            $item_id = $_POST['itemid'];
            $user_id = $_SESSION['user_id'];
            $addreviewreuslt = $this->productlist->addtoreview($rating, $comment, $item_id, $user_id);
            foreach ($addreviewreuslt as $value) {
                
            }
            if ($addreviewreuslt == true) {
                //echo json_encode(array($addreviewreuslt));
                echo json_encode($value);
            } else {
                echo json_encode(array('status' => 1, 'msg' => 'you already insert review in this product'));
            }
        } else {
            echo "1-";
            exit;
        }
    }

    public function filterProducts() {
        $sizeArray = json_decode($_POST['productSize'], true);
        $colorArray = json_decode($_POST['productColor'], true);
        $sortArray = json_decode($_POST['productSort'], true);
        $minval = $_POST['minVal'];
        $maxval = $_POST['maxVal'];
        $product = "";
        $this->load_model("ProductList");
        $show_products = $this->productlist->fetchProduct($sizeArray, $colorArray, $sortArray, $minval, $maxval);
        $product = "";
        if (!empty($show_products)) {
            
            foreach ($show_products as $value) {
                $assets_url = ASSETS_URL;
                $product = "<div class='col-sm-4 img1'><div class='bg'><a href=" . SITE_URL . "product/detail/" . $value['id'] . "><img src=" . ASSETS_URL . "/image/" . $value['item_images_url'] . ".jpg" . " class='img-responsive mainimg'></a><center class='product_button'><a href=" . SITE_URL . "product/detail/" . $value['id'] . "><button type='button' class='btn btn-default middle'>ADD TO CART </button> </a> </center>
            </div><div class='caption'><article  class='artical_text'>" . $value['item_name'] . "<br/><b  class='prize_color'>$" . $value['price'] . "</b><br></article></div></div>";
                echo $product;
            }
        } else {
            echo 1;
        }
        exit;
    }

}
