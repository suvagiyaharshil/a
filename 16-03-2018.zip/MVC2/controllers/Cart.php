<?php

class Cart extends BaseController {

    public function index() {
        $this->load_view('header');
        $this->load_view('cart');
//                $this->load_model("ProductList");
//        $getItemData=$this->productlist->getvaritonid(1);
//        
//                    $qty=array('qty'=>5);
//                    $size=array('size'=>'S');
//        var_dump(array_merge($getItemData,$qty,$size));
//        die();
        if (isset($_POST['news'])) {
            $this->load_model('NewsModel');
            $this->newsmodel->newsInsert($_POST);
        }
        $this->load_view('footer');
    }

    public function addtocart() {
        $size = $_POST['size'];
        $qty1 = $_POST['qty'];
        $id = $_POST['id'];
        $prevois = $_SERVER['HTTP_REFERER'];
        $this->load_model("ProductList");
        $getData = $this->productlist->getproduct($id, $size);
        foreach ($getData as $product) {
            
        }
        $id1 = $product["id"];
        if (empty($_SESSION["cart"])) {
            $i = 0;
            $qty = array('qty' => $qty1);
            $_SESSION['cart'][$i++] = array_merge($product, $qty);
        } else {
            $flag = 0;
            $idIndex = 0;
            foreach ($_SESSION["cart"] as $index => $indata) {
                if ($indata['id'] == $id1) {
                    $flag = 1;
                    $idIndex = $index;
                    break;
                }
            }
            if ($flag == 0) {
                foreach ($_SESSION['cart'] as $i => $value) {
                    
                }
                $qty = array('qty' => $qty1);
                $_SESSION['cart'][++$i] = array_merge($product, $qty);
            } else {
                $_SESSION["cart"][$idIndex]['qty'] = $_SESSION["cart"][$idIndex]['qty'] + $qty1;
            }
        }
        echo "1-" . $prevois;
        exit;
    }

    public function deletecart($id) {
        $previos_page = $_SERVER["HTTP_REFERER"];
        foreach ($_SESSION['cart'] as $i => $usetvalue) {
            if ($usetvalue['id'] == $id) {
                unset($_SESSION['cart'][$i]);
            }
        }

        echo "<script>window.location.replace(\"$previos_page\");</script>";
    }

    public function updatecart($data) {
        $previos_page = $_SERVER["HTTP_REFERER"];
        $qty = $_POST['qty'];
        $id = $_POST['id'];
        foreach ($_SESSION['cart'] as $index => $indata) {
            if ($indata[0][0] == $id) {
                $flag = 1;
                $idIndex = $index;
                break;
            }
        }
        if ($flag == 1) {
            foreach ($_SESSION['cart'] as $i => $value) {
                $_SESSION['cart'][$idIndex]['qty'] = $qty;
            }
        } else {
            die("flag not set");
        }
        echo "<script>window.location.replace(\"$previos_page\");</script>";
    }

    public function deleteallcart() {
        $previos_page = $_SERVER["HTTP_REFERER"];
        unset($_SESSION['cart']);
        echo "<script>window.location.replace(\"$previos_page\");</script>";
    }

    public function updateCart1() {
        $data = $_POST["result"];
        $data = json_decode("$data", true);
        foreach ($data as $qty_id) {
            foreach ($_SESSION["cart"] as $index => $indata) {
                if ($indata['id'] == $qty_id['id']) {
                    $flag = 1;
                    $idIndex = $index;
                    break;
                }
            }
            if ($flag == 1) {
                foreach ($_SESSION['cart'] as $i => $value) {
                    $_SESSION['cart'][$idIndex]['qty'] = $qty_id['qty'];
                }
            }
        }
        print_r($_SESSION['cart']);
    }

}
