<?php
class Profile extends BaseController {
    public function index() {
        if (checkIfLogin()) {
            $this->load_model("ProfileModel");
            $userinfo = $this->profilemodel->getUser();
            $data['value'] = $userinfo->fetch_assoc();
            $shiping_set = $data['value']['shipping_add_id'];
            $data['country_shoping'] = $this->profilemodel->country_s();
            if (isset($shiping_set)) {
                $data['address'] = $this->profilemodel->getsaddress($shiping_set);
                $country_id = $data['address'][0]['country_id'];
                $data['state'] = $this->profilemodel->getsstate($country_id);
            }
            $biling_set = $data['value']['billing_add_id'];
            $data['country_biling'] = $this->profilemodel->country_b();
            if (isset($biling_set)) {
                $data['address_biling'] = $this->profilemodel->getbaddress($biling_set);
                $country_id = $data['address_biling'][0]['country_id'];
                $data['state_set_biling'] = $this->profilemodel->getbstate($country_id);
            }
            $this->load_view('header');
            $this->load_view('profile', $data);
            if (isset($_POST['news'])) {
                $this->load_model('NewsModel');
                $this->newsmodel->newsInsert($_POST);
            }
            $this->load_view('footer');
        } else {
            echo "<script>window.location('home');</script>";
        }
    }

    public function state_shoping() {
        $this->load_model("ProfileModel");
        $getstate = $this->profilemodel->insert_state_s($_POST);
        echo json_encode($getstate);
    }

    public function state_biling() {
        $this->load_model("ProfileModel");
        $getstate = $this->profilemodel->insert_state_b($_POST);
        echo json_encode($getstate);
    }

    public function update_data() {
        $previos_page = $_SERVER["HTTP_REFERER"];
        $this->load_model("ProfileModel");
        $userinfo = $this->profilemodel->getUser();
        $data['value'] = $userinfo->fetch_assoc();
        $shiping_set = $data['value']['shipping_add_id'];
        $biling_set = $data['value']['billing_add_id'];
        $updatedata = $this->profilemodel->update_user($_POST, $shiping_set, $biling_set);
        if ($updatedata == true) {
            echo "<script>window.location.replace(\"$previos_page\");</script>";
        } else {
            echo "<script>alert('email are alredy register');window.location.replace(\"$previos_page\");</script>";
        }
    }

    public function change_password() {
        $this->load_view('header');
        $this->load_model("ProfileModel");
        $this->profilemodel->change_Password($_POST);
        $this->load_view('change_password');
        if (isset($_POST['news'])) {
            $this->load_model('NewsModel');
            $this->newsmodel->newsInsert($_POST);
        }
        $this->load_view('footer');
    }

}
