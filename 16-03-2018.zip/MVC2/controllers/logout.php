<?php

class Logout extends BaseController {
    public function index() {
        session_unset();
        session_destroy();
        unset($_SESSION['cart']);
        $this->redirect();
    }

}
