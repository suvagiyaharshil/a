<?php

class home_product_display extends BaseController {

    public function index() {
        $this->load_model('ProductList');
        $item_ids = Array();
        $limit = $_POST['limit'];
        $result = $this->productlist->home_showImg($limit);
        $rows = mysqli_num_rows($result);  
        if ($limit > $rows) {
            ?>
            <script>
                $("#home_more_product_btn").hide();
                $("#no_more_data").html("Sorry No More Products....");
            </script>
            <?php
        } else {
            
        }
          while ($value = $result->fetch_assoc()) {
              $id=$value['id'];
              //$i_o_id=$value['i_o_id'];
//                 echo "<pre>";
//        print_r($value);       
// exit();
            ?>
            <section class="col-sm-3 img1">                
                    <div class="bg">
                        <a href="<?php echo SITE_URL; ?>product/detail/<?php echo $id ?>"><img class="img-responsive mainimg" src="<?php echo ASSETS_URL ?>image/<?php echo $value['item_images_url']; ?>.jpg" alt="alt"></a>
                    </div>    
                    <div class="overlay">
                        <center class="product_button"><a href="<?php echo SITE_URL; ?>product/detail/<?php echo $id ?>"<button type="button" class="btn btn-default middle">ADD TO CART</button></a></center>
                    </div>            
                    <div class="caption"><article class="artical_text"><?php echo $value['name']; ?><br/>
                        <b class="prize_color"><?php echo $value['price']; ?></b></article>
                    </div>   
                </section>
       <?php
}
    }
}
   
