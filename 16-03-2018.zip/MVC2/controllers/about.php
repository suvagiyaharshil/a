<?php

class About extends BaseController {
    public function index() {
        $this->load_view('header');
        $this->load_view('about');
        if(isset($_POST['news'])) {
        $this->load_model('NewsModel');    
        $this->newsmodel->newsInsert($_POST);    
        }
        $this->load_view('footer');
    }
}
