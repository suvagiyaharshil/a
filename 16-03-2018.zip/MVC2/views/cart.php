<?php
$assets_url = ASSETS_URL;
?>
<body onload="updatesubtotal();">
    <div class="wap container-fluid">
        <?php include './header.php'; ?> 
    </div>
    <img src="<?php echo ASSETS_URL; ?>/image/inner-banner.jpg" alt="Banner" class="img-responsive banner"/>
    <div class="container-fluid mediabg ">
        <div class="container">
            <div class="row">
                <h2 class="about">Shopping Cart</h2>
            </div>
            <div class="row">
                <ol class="breadcrumb mediabg">
                    <li class="breadcrumb-item"><a href="home" class="mediabg_color">Home</a></li>
                    <li class="breadcrumb-item"><a href="cart" class="active_breadcrumb">Shopping Cart</a></li>
                </ol>
            </div>

        </div>
        <div>

        </div>
    </div>

    <div class="container cart_alert">
        <div class="row">
            <div class="alert alert-success alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <object type="image/svg+xml" data="<?php echo ASSETS_URL; ?>/image/success.svg" height="15px" width="15px">
                </object>
                &nbsp;US Polo Assn FullSleeve Plain T-Shirts for Men Was Added To Your Shopping Cart
            </div> 

<!--            <div class="alert alert-info alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <object type="image/svg+xml" data="<?php echo ASSETS_URL; ?>/image/info.svg" height="15px" width="15px">
                </object>
                &nbsp; US Polo Assn FullSleeve Plain T-Shirts for Men Was Added To Your Shopping Cart
            </div> 

            <div class="alert alert-warning alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <object type="image/svg+xml" data="<?php echo ASSETS_URL; ?>/image/warning.svg" height="15px" width="15px">
                </object>    
                &nbsp;US Polo Assn FullSleeve Plain T-Shirts for Men Was Added To Your Shopping Cart
            </div> 
            <div class="alert alert-danger alert-dismissable">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <object type="image/svg+xml" data="<?php echo ASSETS_URL; ?>/image/error.svg" height="15px" width="15px">
                </object>     
                &nbsp;US Polo Assn FullSleeve Plain T-Shirts for Men Was Added To Your Shopping Cart
            </div> -->
        </div>
    </div>    
    <div class="container">
        <div class="row">
            <div class="col-sm-12 cart_table_col_border">
                <div class="table-responsive">          
                    <table class="table">
                        <thead class="cart_table_header">
                            <tr>
                                <th></td>    
                                <th>Product Name</th>
                                <th></th>
                                <th>Unit Price</th>
                                <th>Qty</th>
                                <th>Subtotal</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($_SESSION['cart'])) { ?>
                            <h4 class="itemsadded"> No Added Items in cart</h4>
                            <?php
                        } else {
                            foreach ($_SESSION['cart'] as $value) {
                                
                                $itemPerTotal = $value['price']  * $value['qty'];
                                $subtotal += $itemPerTotal;
                                ?>
                                <tr>
                                    <td><img src="<?php echo $assets_url; ?>image/<?php echo $value['item_images_url'] ?>.jpg" style="height: 120px;" class="cart_image"></td>
                                    <td> <?php  echo $value['name'] ?><br><b><span>Color:</span></B><br><?php  echo $value['color'] ?><BR/><B><span>Size:</span></B><br><span><?php echo $value['value'] ?></span></td>
                                    <td><object type="image/svg+xml" data="<?php echo $assets_url; ?>image/edit-dark.svg" height="15px" width="15px"></object></td>
                                    <td class="Cart_price_color"><p class="price" id="price1" name="price1">$<?php echo $value['price'] ?>.00</p></td>
                                    
                                    <input type="hidden" name="id" id="id" value="<?php  echo $value['id']; ?>" >
                                    <td class="cart_table_border1">
                                        <input type="text" id="qty1" name="qty1" value="<?php echo $value['qty'] ?>" class="textbox_cart" onkeyup="updatetotal()">
                                    </td>
                                    <td class="Cart_price_color"><p id="subtotal1" name="subtotal1">$<?php echo $itemPerTotal; ?>.00</p></td>
                                    <td><a href="<?php echo SITE_URL; ?>cart/deletecart/<?php echo $value['id']; ?>"><div class="cart_delete"></div></td>
                                </tr>
                            <?PHP }
                        } ?>
                        <tr class='cart_table_header'>
                            <td colspan='3'><a href="<?php echo SITE_URL; ?>"><button type='button' class='btn btn-default reg_clear cart_update_button'>Continue Shopping</button></a></td>
                        <input type="hidden" value="<?php echo $value['id'];?>" id="update_id">
                        <td colspan='5' class='cart_table_footer'><a href="<?php echo SITE_URL; ?>cart/deleteallcart"><button type='button' class='btn btn-default reg_clear1 cart_update_button'>Clear Shopping Cart</button></a>
                        <button type='button' id="updatecart" class='btn btn-default reg_clear1 cart_update_button'>Update Shopping Cart</button></td>
                            <!--     
                            <tr>
                               <td><img src="image/cart-img01.jpg"/></td>
                               <td> US Polo Assn FullSleeve Plain T-Shirts for Men<br/><b>Color</b><br/>Blue<br/><b>Size</b><br/>M</td>
                               <td><object type="image/svg+xml" data="image/edit-dark.svg" height="15px" width="15px">
                               </object></td>
                               <td class="Cart_price_color"><p id="uprice2">$252</p></td>
                               <td class="cart_table_border1"><p id="qty1">1</p></td>
                               <td class="Cart_price_color"><p id="subtotal1">$252</p></td>
                               <td><object type="image/svg+xml" data="image/cross-dark.svg" height="15px" width="15px">
                               </object></td>
                               
                           </tr>
                           
                           <tr>
                               <td><img src="image/cart-img01.jpg"/></td>
                               <td> US Polo Assn FullSleeve Plain T-Shirts for Men<br/><b>Color</b><br/>Blue<br/><b>Size</b><br/>M</td>
                               <td><object type="image/svg+xml" data="image/edit-dark.svg" height="15px" width="15px">
                               </object></td>
                               <td class="Cart_price_color"><p id="uprice3">$238</p></td>
                               <td class="cart_table_border1"><p id="qty1">1</p></td>
                               <td class="Cart_price_color"><p id="subtotal1">$238</p></td>
                               <td><object type="image/svg+xml" data="image/cross-dark.svg" height="15px" width="15px">
                               </object></td>
                           </tr>
                           <tr>
                               <td><img src="image/cart-img01.jpg"/></td>
                               <td> US Polo Assn FullSleeve Plain T-Shirts for Men<br/><b>Color</b><br/>Blue<br/><b>Size</b><br/>M</td>
                               <td><object type="image/svg+xml" data="image/edit-dark.svg" height="15px" width="15px">
                               </object></td>
                               <td class="Cart_price_color"><p id="uprice4">$340</p></td>
                               <td class="cart_table_border1"><p id="qty1">1</p></td>
                               <td class="Cart_price_color"><p id="subtotal1">$340</p></td>
                               <td><object type="image/svg+xml" data="image/cross-dark.svg" height="15px" width="15px">
                               </object></td>
                           </tr>-->

                            </tbody>
                    </table>
                </div>
            </div> 
        </div>
    </div>   
    <br/>
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="row">
                    <div class="col-sm-9 well cart_table">
                        <h4>Estimate Shopping And Tax</h4>
                        <h5>Enter your destination to get a shipping estimate</h5>
                        <form action="/action_page.php">
                            <div class="form-group">
                                <label for="exampleSelect1">Country:</label>
                                <select class="form-control" id="exampleSelect1">
                                    <option>india</option>
                                    <option>us</option>
                                    <option>uk</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>State/Province:</label>
                                <input type="text" class="form-control" id="email" placeholder="State/Province" name="email">
                            </div>
                            <div class="form-group">
                                <label>Zip/Postal Code</label>
                                <input type="password" class="form-control" id="pwd" placeholder="Zip/Postal Code" name="pwd">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="row">
                    <div class="col-sm-4">

                    </div>
                    <div class="col-sm-8">
                        <div class="panel panel-default" style="margin-right: -15px;">
                            <div class="panel-body">
                                <table class="cart_panel_table product" >
                                    <tr>
                                        <td>subtotal</td>
                                        <td><P id="total1">$<?php echo "$subtotal"; ?>.00</P></td>
                                    </tr>
                                    <tr>
                                        <td class="cart_total_font"><b>Total</b></td>
                                        <td><b class="Cart_price_color cart_total_font"><P id="total">$<?php echo "$subtotal"; ?>.00</P></b></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2"><button type="submit" id="updatecart" class="btn btn-default cart_update_button">Update Shopping Cart</button></a></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="panel-footer">Checkout With Multiple Address</div>
                        </div>
                    </div>
                </div>
            </div>       
        </div>
    </div>
    <button type="button" class="top_arrow" id="top" onclick="gototop();"><object type="image/svg+xml" data="<?php echo ASSETS_URL; ?>/image/up-arrow-white.svg" height="15px" width="15px">
        </object></button>