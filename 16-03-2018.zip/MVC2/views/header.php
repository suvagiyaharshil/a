<?php
$assets_url = ASSETS_URL;
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="shortcut icon" href="<?php echo $assets_url; ?>image/favicon.ico" />
        <title><?php echo (isset($title) ? $title : 'eShopper'); ?></title>
        <!--CSS -->
        <link rel="stylesheet" type="text/css" href="<?php echo $assets_url; ?>/css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="<?php echo $assets_url; ?>/css/main.css"/>
        <script type="text/javascript" src="<?php echo $assets_url; ?>/js/jquery.min.js"></script>
        <!--Js -->
        <script>
            var assets_url = '<?php echo $assets_url; ?>';
            var site_url = '<?php echo SITE_URL; ?>';
            var user_id = '<?php echo getUserId(); ?>';
        </script>
    </head>
    <body>
        <header class="container-fluid">
            <nav class="navbar navbar-inverse navbar-custom navbar-fixed-top">
                <div class="container">
                    <div class="row">
                        <div class="navbar-header">
                            <div class="col-sm-1">
                                <a class="navbar-brand logo" href="/"></a>
                                <button type="button" class="navbar-toggle btntoggle" data-toggle="collapse" data-target="#myNavbar">
                                    <span class="icon-bar icontoggle"></span>
                                    <span class="icon-bar icontoggle"></span>
                                    <span class="icon-bar icontoggle"></span>                        
                                </button>
                            </div>
                        </div>

                        <div class="collapse navbar-collapse fixedmenu col-sm-5 col-xs-12" id="myNavbar">
                            <ul class="nav navbar-nav colornav">
                                <li><a href="/" class="menu_color">HOME</a></li>
                                <?php
                                $this->load_model("HeaderModel");
                                $parentCat = $this->headermodel->getParCategories();
                               while ($value = $parentCat->fetch_assoc()) {
                                    $category_id = $value['id'];?>
                                <li class="dropdown htext" value="<?php echo $category_id; ?>"><a href="#" class="dropdown-toggle headtext menu_color" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $value['name']; ?> </a>
                                    <ul class="dropdown-menu lihov">
                                        <?php
                                    $subCat = $this->headermodel->getSubCategories($category_id);
                                    while ($value2 = $subCat->fetch_assoc()) {
                                        ?>
                                        
                                        <li class="lihov" value="<?php echo $value2['id']; ?>"><a href="<?php echo SITE_URL; ?>product/index/<?php echo $value2['id']; ?>"> <?php echo $value2["name"] ;?></a></li>
                                    <?php
                                    }
                                    echo "</ul></li>";
                                }
                                ?>   
                            </ul>
                        </div>
                        <div class="col-sm-6 col-xs-12 rightnav pull-right">
                            <ul class="nav navbar-nav navbar-right rightnav">
                                <ul class="nav navbar-nav navbar-right">
                                    <?php if (!checkIfLogin()) { ?>
                                        <li><a href="#" style="color: #ea4748;" data-toggle="modal" data-target="#myModal">Login</a></li>
                                    <?php } else {
                                        ?>
                                        <li><div class="username">Welcome,<?php echo getLoginUserName(); ?></div></li>
                                        <li><div class="seprator hide-small"></div></li>

                                        <li><a href="<?php echo SITE_URL . 'profile'; ?>" style="color: #414141;" >Profile</a></li>
                                    <?php } ?>
                                    <?php if (checkIfLogin()) { ?>
                                        <li><div class="seprator"></div></li>
                                        <li><a href="<?php echo SITE_URL . 'logout'; ?>" style="color: #ea4748;" class="rightnavlogin">Logout</a></li>
                                    <?php } ?>
                                    <li><div class="seprator"></div></li>
                                    <li class="cart dropdown"><a class="dropdown-toggle" data-toggle="dropdown"><!-- <a data-toggle="popover" id="cartpop" data-container="body" data-placement="bottom"  data-html="true" > --></a>
                                        <div class="dropdown-menu popcart">
                                            <div class="col-sm-12 itemsadded">
                                                <h4>Recently Added Items(s)</h4>
                                            </div>
                                            <table class="table">
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <div><img src="<?php echo $assets_url; ?>image/cart-img01.jpg"></div>
                                                        </td>
                                                        <td>
                                                            <p>U.S Polo Assn.Full Sleve Plain T-Shirt...<br><span class="color">$120</span><br><span class="color2">Qty:1</span><br>
                                                                <span class="color2">Size:Medium/Large</span></p>
                                                        </td>
                                                        <td>
                                                            <div class="edit"></div>
                                                        </td>
                                                        <td>
                                                            <div class="delete"></div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div><img src="<?php echo $assets_url; ?>image/cart-img01.jpg"></div>
                                                        </td>
                                                        <td>

                                                            <p>U.S Polo Assn.Full Sleve Plain T-Shirt...<br><span class="color">$120</span><br><span class="color2">Qty:1</span><br>
                                                                <span class="color2">Size:Medium/Large</span></p>
                                                        </td>
                                                        <td>
                                                            <div class="edit"></div>
                                                        </td>
                                                        <td>
                                                            <div class="delete"></div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="4">
                                                            <p>Cart Subtotal:<span class="color">$168.00</span></p>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="4">
                                                            <button type="button" class="btn btn-default cart_update_button center-block">View Cart

                                                            </button>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="seprator"></div>
                                    </li>
                                    <li>
                                        <div class="box">
                                            <input class="searchtext" type="search" placeholder="Search" />
                                        </div>
                                        <div class="icon">
                                            <a href="#">
                                                <div class="search"></div>
                                            </a>
                                        </div>
                                    </li>
                                </ul>
                        </div>
                    </div>
                </div>
            </nav>
        </header>
        <div class="cart_container">
            <div class="collapse cart_click cart_click_bg" id="cart" <?php
            if (empty($_SESSION["cart"])) {
                echo "style='height:66px;'' ";
            }
            ?>>
                <div class="col-sm-12 itemsadded scroll-area">
                    <?php if (empty($_SESSION['cart'])) { ?>
                        <h4 class="itemsadded"> No Added Items in cart</h4>
                        <?php
                    } else {
                        ?>
                        <h4>Recently Added Items(s)</h4>

                    </div>
                <div class="testtable">
                    <table class="table table-fixed testbody" >
                        <tbody>
                            <?php
                            foreach ($_SESSION['cart'] as $value) {
                                $itemPerTotal = $value['price'] * $value['qty'];
                                $subtotal += $itemPerTotal;
                               
                                ?>
                                <tr>
                                    <td>
                                        <div class="imgcart"><img src="<?php echo $assets_url; ?>image/<?php echo $value['item_images_url'] ?>.jpg"></div>
                                    </td>
                                    <td>
                                        <p><?php echo $value['name']?><br><span class="color">$<?php echo $value['price'] ?></span><br><span class="color2">Qty:<?php echo $value['qty'] ?></span><br>
                                            <span class="color2">Size:<?php echo $value['value'] ?></span></p>
                                    </td>
                                    <td>
                                        <div class="edit"></div>
                                    </td>
                                    <td>
                                        <a href="<?php echo SITE_URL; ?>cart/deletecart/<?php echo $value['id']; ?>"><div class="delete"></div></a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                        <tr>
                            <td colspan="4">
                                <p>Cart Subtotal:<span class="color">$<?php echo $subtotal; ?>.00</span></p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4">
                                <a href="<?php echo SITE_URL; ?>cart"><button type="button" class="btn btn-default btn1 center-block">View Cart
                                    </button>
                                </a> 
                            </td>
                        </tr>
                    </table>
                </div>
            <?php } ?>
        </div>               
    </div>
    <div class="modal fade" tabindex="-1" role="dialog" id="myModal" aria-labelledby="mySmallModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="alert alert-dismissible alert-danger login_alert" role="alert" style="display:none">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                        
						<span class="login_msg"></span>
                    </div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <center><h4 class="modal-title" id="myModalLabel">eShopper Login</h4></center>
                </div>
                <form action="" name="login" id="login" method="POST">
                    <div class="modal-body">
                        <div class="form-group reg_field">
                            Username
                            <input type="text" class="form-control" id="" name="username" placeholder="Please enter user name">
                        </div>
                        <p id="username_error"></p>
                        <div class="form-group reg_field">
                            Password
                            <input type="password" class="form-control" id="exampleFormControlInput1" name="password" placeholder="Please enter password">
                        </div>
                        <p id="password_error"></p>
                    </div>
                    <div class="modal-footer"> 
                        <button type="submit" name="login" class="btn btn-default footer_button login_model_button" value="submit">Login</button>
                        Not a Member?<a href="/register" class="login_model_link">Register</a>
                    </div>
                </form>
            </div>
        </div>
    </div>