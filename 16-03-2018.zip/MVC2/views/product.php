<?php
$assets_url = ASSETS_URL;
foreach ($price as $priceVal) {
    $minPrice = $priceVal['minPrice'];
    $maxPrice = $priceVal['maxPrice'];
}
?>
<link rel="stylesheet" type="text/css" href="<?php echo $assets_url; ?>/css/priceSlider.css"/>
<script type="text/javascript" src="<?php echo $assets_url; ?>js/priceSlider.js"></script>
<body>
    <div class="wap container-fluid">
    </div>
    <img src="<?php echo $assets_url; ?>image/inner-banner.jpg" alt="Banner" class="img-responsive banner"/>
    <div class="container-fluid mediabg">
        <div class="container">
            <h2 class="about">Men</h2>
            <div class="row">
                <ol class="breadcrumb mediabg">
                    <li class="breadcrumb-item"><a href="/home" class="mediabg_color">Home</a></li>
                    <li class="breadcrumb-item"><a href="/product" class="mediabg_color">Men</a></li>
                    <li class="breadcrumb-item"><a href="/product" class="active_breadcrumb">T-Shirts</a></li>
                </ol>
            </div>
        </div>
    </div>
    <br/><br/>
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="accordion_border">
                    <p class="accordion_title">FILTER BY</p>
                    <!--                    <div class="panel-group detail_panel_group" id="accordion" role="tablist" aria-multiselectable="true">
                                            <div class="panel panel-default detail_panel_border">
                                                <div class="panel-heading product_panel" role="tab" id="headingOne">
                                                    <h4 class="panel-title">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                            <b>CATEGORIES</b>
                                                        </a>
                                                    </h4>
                                                </div>    
                                            </div>
                                        </div> 
                                        <div id="collapseOne" class="panel-collapse collapse in product_col_cat" role="tabpanel" aria-labelledby="headingOne">
                                            <div class="panel-body">
                                                                        <div class="form-check product_col_cat_checkbox">
                                                                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> T-shirts(25275)
                                                                            </div>
                                                
                                                                            <div class="form-check product_col_cat_checkbox">
                                                                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> shirts(24866)
                                                                            </div>
                                                                            <div class="form-check product_col_cat_checkbox">
                                                                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> Jacketes(5326)
                                                                            </div>
                                                
                                                                            <div class="form-check product_col_cat_checkbox">
                                                                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> Sweaters(4871)
                                                                            </div>
                                                
                                                                            <div class="form-check product_col_cat_checkbox">
                                                                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">  Sweatshirts(4533)
                                                                            </div>
                                                
                                                                            <div class="form-check product_col_cat_checkbox">
                                                                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">  Kurtas(1566)
                                                                            </div>
                                            </div>
                                        </div>
                    -->
                    <div class="panel panel-default detail_panel_border">
                        <div class="panel-heading product_panel" role="tab" id="headingTwo">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="#collapseTwo">
                                    <b>COLOUR</b>
                                </a>
                            </h4>
                        </div>    
                    </div>

                    <div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
                        <div class="panel-body">
                            <!--                            <label class="container_checkbox">Magenta(1250)
                                                            <input type="checkbox" checked="checked">
                                                            <span class="checkmark1"></span>
                                                        </label>
                                                        <label class="container_checkbox" style="opacity: 0.5;">Pink(150)
                                                            <input type="checkbox" checked="checked" disabled>
                                                            <span class="checkmark2"></span>
                                                        </label>
                                                        <label class="container_checkbox">Red(100)
                                                            <input type="checkbox" checked="checked">
                                                            <span class="checkmark3"></span>
                                                        </label>
                                                        <label class="container_checkbox">Lavender(250)
                                                            <input type="checkbox" checked="checked">
                                                            <span class="checkmark4"></span>
                                                        </label>
                                                        <label class="container_checkbox">Navy(50)
                                                            <input type="checkbox" checked="checked">
                                                            <span class="checkmark5"></span>
                                                        </label>
                                                        <label class="container_checkbox">Blue(1220)
                                                            <input type="checkbox" checked="checked">
                                                            <span class="checkmark6"></span>
                                                        </label>
                                                        <label class="container_checkbox">Grey(2250)
                                                            <input type="checkbox" checked="checked">
                                                            <span class="checkmark7"></span>
                                                        </label>
                                                        <label class="container_checkbox">Teal(1350)
                                                            <input type="checkbox" checked="checked">
                                                            <span class="checkmark8"></span>
                                                        </label>
                                                        <label class="container_checkbox">Peach(1550)
                                                            <input type="checkbox" checked="checked">
                                                            <span class="checkmark9"></span>
                                                        </label>
                                                        <label class="container_checkbox">Orange(10)
                                                            <input type="checkbox" checked="checked">
                                                            <span class="checkmark10"></span>
                                                        </label>-->
                            <?php
                            foreach ($color as $value) {
                                $color_id = $value['id'];
                                $resultColor = $this->productlist->totalProductInColor($color_id);
                                while ($value2 = $resultColor->fetch_assoc()) {
                                    ?>
                                    <div class="row">
                                        <div class="col-sm-2 col-xs-2">
                                                                                    <!--    <button style="cursor: none; border: none; background-color: <?php echo $value['value']; ?>; border-radius: 20px;" >
                                                                                        <input type="checkbox" class="color" style="opacity: 0" value="<?php echo $value['value']; ?>">
                                                                                    </button>
                                                                                </div>-->
                                            <label class="container_checkbox" >
                                            <input type="checkbox" class="color" value="<?php echo $value['value']; ?>">
                                            <span class="checkmark1" style="background-color: <?php echo $value['value']; ?>;"></span>
                                        </label>
                                        </div>
                                        <div class="col-sm-10 col-xs-10 bgcolortxt p">
                                            <p><?php echo $value['value']; ?>(<?php echo $value2['total']; ?>)</p>
                                        </div>
                                        <input type="hidden" name="color" value="<?php echo $value['value']; ?>">
                                    </div>
                                    <?php
                                }
                            }
                            ?>

                            <a href="<?Php ?>" class="product_reset">Reset</a>
                        </div>

                    </div>
                    <div class="panel panel-default detail_panel_border">
                        <div class="panel-heading product_panel" role="tab" id="headingThree">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="#collapseThree">
                                    <b>PRICE</b>
                                </a>
                            </h4>
                        </div>    
                    </div>

                    <div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
                        <div class="panel-body">
<!--                            <center>31 items</center>
                            <img src="<?php echo ASSETS_URL; ?>image/price.jpg" class="img-responsive"/>
                            RS. 174
                            <p class="detail_price_pos">RS. 899</p>-->

                            <div class="panel-body">

                                <p>
                                    <label for="amount">Price range:</label>
                                    <br>
                                </p>
                                <div id="slider-range"></div>  <br>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <input type="text" id="amount1" readonly style="border:0; font-weight:bold;" value="<?php echo $minPrice ?>">
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" id="amount2" readonly style="border:0;font-weight:bold;margin-left: 44px;" value="<?php echo $maxPrice ?>" >
                                    </div>    
                                </div>

                            </div>

                        </div>
                    </div>

                    <div class="panel panel-default detail_panel_border">
                        <div class="panel-heading product_panel" role="tab" id="headingFour">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true" aria-controls="#collapseFour">
                                    <b>SIZE</b>
                                </a>
                            </h4>
                        </div>    
                    </div>

                    <div id="collapseFour" class="panel-collapse collapse in product_col_cat" role="tabpanel" aria-labelledby="headingFour">
                        <div class="panel-body">
                            <?php
                            while ($value = $size->fetch_assoc()) {
                                $size_id = $value['id'];
                                $resultSize = $this->productlist->totalProductInSize($size_id);
                                while ($value2 = $resultSize->fetch_assoc()) {
                                    ?>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" class="size" name="size_chk[]" value=" <?php echo $value['id']; ?>">
                                            <?php echo $value['value'] . "(" . $value2['total'] . ")"; ?>
                                        </label>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                            <!--                            <div class="form-check product_col_cat_checkbox">
                                                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> XXS(81)
                                                        </div>
                            
                                                        <div class="form-check product_col_cat_checkbox">
                                                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> XS(1446)
                                                        </div>
                                                        <div class="form-check product_col_cat_checkbox">
                                                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> S(240706)
                                                        </div>
                            
                                                        <div class="form-check product_col_cat_checkbox">
                                                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> M(29467)
                                                        </div>
                            
                                                        <div class="form-check product_col_cat_checkbox">
                                                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> L(29516)
                                                        </div>
                            
                                                        <div class="form-check product_col_cat_checkbox">
                                                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> XL(27823)
                                                        </div>
                            
                                                        <div class="form-check product_col_cat_checkbox">
                                                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> XXL(16841)
                                                        </div>
                            
                                                        <div class="form-check product_col_cat_checkbox">
                                                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1"> XXXL(43)
                                                        </div>-->
                        </div>
                    </div>
                </div><br/>
                <div class="row">
                    <div class="col-sm-12">
                        <a href="#"><img src="<?php echo $assets_url; ?>image/promo2.jpg" alt="add" class="img-responsive"/></a>
                    </div>
                </div>
            </div>    
            <div class="col-sm-9">
                <div class="row">
                    <div class="col-sm-12">
                        <p class="product_title">Men T-shirts</p>
                    </div>
                </div>    
                <div class="row inlineform" id="sort_view">
                    <div class="col-sm-12">
                        <form class="form-inline" action="">
                            <div class="form-group pull-right">
                                <label for="sel1">Sort By</label>
                                <select class="form-control position" id="position">

                                    <option value="1" selected>PRICE</option>
                                    <option value="2">NAME</option>

                                </select>
                            </div>
                        </form>
                    </div>      
                </div>



                <br/>
                <div class="row">
                    <div class="col-sm-12">
                        <div id="loading_image" style="display: none;text-align: center;"><img src="<?php echo $assets_url; ?>image/loading.gif" alt="Loading..." style="width:300px;"></div>
                    </div>
                </div>   
                <div id="">
                    <div id="product_imgs">
                    </div>
                    <div class="row">
                        <div>

                            <input type="hidden" id="limit" value="3">
                            <center><button type="button" id="more_product_btn" class="btn btn-default cart_update_button product_button">More Products</button></center>
                        </div>
                    </div>    
                </div>
                <span id="no_more_data" style="display: none;"><center><h1>Sorry No Products</h1></center></span>    
            </div>
        </div>
    </div>
    <button type="button" class="top_arrow" id="top" onclick="gototop();"><object type="image/svg+xml" data="<?php echo $assets_url; ?>image/up-arrow-white.svg" height="15px" width="15px">
        </object></button>
