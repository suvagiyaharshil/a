<?php
$assets_url = ASSETS_URL;
?>
<img src="<?php echo $assets_url; ?>image/inner-banner.jpg" alt="Banner" class="img-responsive banner"/>
        <div class="container-fluid mediabg">
            <div class="container">
                <h2 class="about">Update Profile</h2>
                <div class="row">
                    <ol class="breadcrumb mediabg">
                        <li class="breadcrumb-item"><a href="home" class="mediabg_color">Home</a></li>
                        <li class="breadcrumb-item"><a href="/profile" class="mediabg_color">Update Profile</a></li>
                        <li class="breadcrumb-item"><a href="change_password" class="active_breadcrumb">Change Password</a></li>
                    </ol>
                </div>
            </div>
            </div>

        <div class="container  padding5">
            
            <form name="change_password" method="post" action="" class="reg_form" >
                <div class="row">
<!--                    <div class="col-sm-6">
                        <div class="form-group reg_field">
                            Current Password
                            <input type="password" class="form-control" name="password" id="password" value="" >
                            <p id="password_error"><?php
                                if (isset($error['password'])) {
                                    echo $error['password'];
                                }
                                ?></p>
                        </div>
                    </div>-->
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group reg_field">
                            New Password
                            <input type="hidden" name="username" value="<?php echo $_SESSION['user_id']; ?>" >
                            <input type="password" class="form-control" name="newpassword" id="password" value="" >
                            <p id="password_error"><?php
                                if (isset($error['newpassword'])) {
                                    echo $error['newpassword'];
                                }
                                ?></p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group reg_field">
                            Retype NewPassword
                            <input type="password" class="form-control" name="renewpassword" id="password" value="" >
                            <p id="password_error"><?php
                                if (isset($error['renewpassword'])) {
                                    echo $error['renewpassword'];
                                }
                                ?></p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                    </div>   
                    <div class="col-sm-6">
                        <button type="submit" class="btn btn-default reg_button reg_submit" name="password_change" id="password">Update</button>
                    </div>    
                </div> 
            </form>
        </div>
