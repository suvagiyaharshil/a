<?php
$assets_url = ASSETS_URL;
?>
<div class="container-fluid wap_home">
    <section class="row">
        <div id="jssor_1">
            <div data-u="slides" class="jssordiv">
                <div data-p="225.00">
                    <img data-u="image" class="img-responsive" src="<?php echo ASSETS_URL; ?>image/banner.jpg" />
                </div>
                <div data-p="225.00">
                    <img data-u="image" class="img-responsive" src="<?php echo ASSETS_URL; ?>image/banner1.jpg" />
                </div>
                <div data-p="225.00">
                    <img data-u="image" class="img-responsive" src="<?php echo ASSETS_URL; ?>image/banner2.jpg" />
                </div>
            </div>

            <!-- Arrow Navigator -->
            <div data-u="arrowleft" class="jssora051 arrow_left" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
                <svg width="30" height="30">
                <image width="30" height="30" href="<?php echo ASSETS_URL; ?>image/pre-arrow.svg" />
                </svg>
            </div>
            <div data-u="arrowright" class="jssora051 arrow_right" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
                <svg width="30" height="30">
                <image width="30" height="30" href="<?php echo ASSETS_URL; ?>image/next-arrow.svg" />
                </svg>
            </div>
        </div>
    </section>
</div>

<div class="container-fluid mediabg">
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="media">
                    <img class="d-flex mr-3">
                    <div class="media-body "><div class="sprite1"></div>
                        <h5 class="mt-0 media_text"><b>Free Delivery Worldwide</b><br/>At vero eos et accusamus et lusto Odlo</h5>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="media">
                    <img class="d-flex mr-3">
                    <div class="media-body"><div class="sprite2"></div>
                        <h5 class="mt-0 media_text"><b>Free Return For 90 Day</b><br/>At vero eos et accusamus et lusto Odlo</h5>        
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="media">
                    <img class="d-flex mr-3">
                    <div class="media-body"><div class="sprite3"></div>
                        <h5 class="mt-0 media_text"><b>Discount on Order Gift</b><br/>At vero eos et accusamus et lusto Odlo</h5>      
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>    

<div class="container">
    <div>
        <center><p class="product_font">Trending Product</p></center>
    </div>
    <div id="">
        <div id="home_product_imgs">
        </div>
        <div class="row">
            <div>
                <center><button type="button" id="home_more_product_btn" class="btn btn-default cart_update_button product_button">More Products</button></center>
            </div>
        </div>    
    </div>
    <span id="no_more_data"></span>    
</div><br>
<button type="button" class="top_arrow" id="top" onclick="gototop();"><object type="image/svg+xml" data="<?php echo ASSETS_URL; ?>image/up-arrow-white.svg" height="15px" width="15px">
    </object></button>


<div class="container-fluid banner_footer2">
    <div class="row">
<!--        <img src="<?php echo ASSETS_URL; ?>image/px.jpg" class="img-responsive banner_footer"> -->
        <div class="footer_font">
            <p><strong>GET THE</strong> LATEST<br><strong>WOMEN</strong> FASHION</p>
            <button type="button" class="btn btn-default">Get Exclusive Collection For Women</button>
        </div>
    </div>
</div>
<br/>

<div class="container">
    <div class="row">
        <div class="col-sm-offset-2 col-sm-8 col-sm-offset-2 col-xs-12 testimonial">
            <h3>Testimonial</h3>
            <div class="col-md-12">
                <div class="carousel slide" data-ride="carousel" id="quote-carousel">

                    <!-- Bottom Carousel Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#quote-carousel" data-slide-to="0" class="active"></li>
                        <li data-target="#quote-carousel" data-slide-to="1"></li>
                        <li data-target="#quote-carousel" data-slide-to="2"></li>
                        <li data-target="#quote-carousel" data-slide-to="3"></li>
                    </ol>

                    <!-- Carousel Slides / Quotes -->
                    <div class="carousel-inner">

                        <!-- Quote 1 -->
                        <div class="item active">
                            <div class="row">
                                <div class="col-sm-12 ">

                                    <hr>
                                    <hr>
                                    <div class="row testcontent">
                                        <div class="col-sm-3">
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo ASSETS_URL; ?>image/testimonial_3.jpg">
                                                </div>
                                                <div class="media-body test_font">
                                                    <h4>John Clay</h4>
                                                    <p>Cyclist</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-9 test_p">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                                cillum dolore eu fugiat nulla pariatur.</p>
                                        </div>
                                    </div>
                                    <hr>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="row">
                                <div class="col-sm-12 ">
                                    <hr>
                                    <hr>
                                    <div class="row testcontent">
                                        <div class="col-sm-3">
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo ASSETS_URL; ?>image/testimonial_3.jpg">
                                                </div>
                                                <div class="media-body test_font">
                                                    <h4>John Clay</h4>
                                                    <p>Cyclist</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-9 test_p">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                                cillum dolore eu fugiat nulla pariatur.</p>
                                        </div>
                                    </div>

                                    <hr>

                                </div>
                            </div>
                        </div>
                        <!-- Quote 2 -->
                        <div class="item">
                            <div class="row">

                                <div class="col-sm-12 testimonial">

                                    <hr>
                                    <hr>
                                    <div class="row test_content">
                                        <div class="col-sm-3">
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo ASSETS_URL; ?>image/testimonial_3.jpg">
                                                </div>
                                                <div class="media-body test_font">
                                                    <h4>John Clay</h4>
                                                    <p>Cyclist</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-9 test_p">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                                cillum dolore eu fugiat nulla pariatur.</p>
                                        </div>
                                    </div>

                                    <hr>

                                </div>
                            </div>
                        </div>

                        <!-- Quote 3 -->
                        <div class="item">
                            <div class="row">
                                <div class="col-sm-12 testimonial">

                                    <hr>
                                    <hr>
                                    <div class="row testcontent">
                                        <div class="col-sm-3">
                                            <div class="media">
                                                <div class="media-left">
                                                    <img src="<?php echo ASSETS_URL; ?>image/testimonial_3.jpg">
                                                </div>
                                                <div class="media-body test_font">
                                                    <h4>John Clay</h4>
                                                    <p>Cyclist</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-9 test_p">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                                cillum dolore eu fugiat nulla pariatur.</p>
                                        </div>
                                    </div>
                                    <hr>

                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script type="text/javascript">


    $(document).ready(function () {

        $('.icon').click(function () {
            $('.search').toggleClass('expanded');
        });

        $('.owl-carousel').owlCarousel({
            items: 1,
            lazyLoad: true,
            loop: true,
            margin: 10,
            autoplay: true,
            autoplayTimeout: 4000,
        });

        var jssor_1_SlideoTransitions = [
            {$Duration: 200, x: -1, y: 1, $Delay: 50, $Cols: 10, $Rows: 5, $Formation: $JssorSlideshowFormations$.$FormationStraightStairs, $Easing: {$Left: $Jease$.$InQuart, $Top: $Jease$.$InQuart, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 500, $Delay: 12, $Cols: 10, $Rows: 5, $Clip: 15, $SlideOut: true, $Formation: $JssorSlideshowFormations$.$FormationZigZag, $Easing: $Jease$.$OutQuad, $Opacity: 2},
            {$Duration: 500, x: 1, y: -1, $Delay: 40, $Cols: 10, $Rows: 5, $SlideOut: true, $ChessMode: {$Column: 3, $Row: 12}, $Easing: {$Left: $Jease$.$InCubic, $Top: $Jease$.$InCubic, $Opacity: $Jease$.$OutQuad}, $Opacity: 2},
            {$Duration: 1600, y: -1, $Delay: 40, $Cols: 24, $SlideOut: true, $Formation: $JssorSlideshowFormations$.$FormationStraight, $Easing: $Jease$.$OutJump, $Round: {$Top: 1.5}},
            {$Duration: 600, $Delay: 20, $Cols: 8, $Rows: 4, $Formation: $JssorSlideshowFormations$.$FormationStraightStairs, $Assembly: 2050, $Opacity: 2},
            {$Duration: 500, $Delay: 12, $Cols: 10, $Rows: 5, $Clip: 15, $SlideOut: true, $Formation: $JssorSlideshowFormations$.$FormationStraightStairs, $Easing: $Jease$.$OutQuad, $Opacity: 2, $Assembly: 2049},
            {$Duration: 1000, x: -0.2, $Delay: 20, $Cols: 16, $SlideOut: true, $Formation: $JssorSlideshowFormations$.$FormationStraight, $Easing: {$Left: $Jease$.$InOutExpo, $Opacity: $Jease$.$InOutQuad}, $Assembly: 260, $Opacity: 2, $Outside: true, $Round: {$Top: 0.5}},
            {$Duration: 600, $Delay: 40, $Rows: 10, $Clip: 8, $Move: true, $Formation: $JssorSlideshowFormations$.$FormationCircle, $Easing: $Jease$.$InBounce, $Assembly: 264},
            {$Duration: 800, x: 1, $Delay: 40, $Cols: 6, $Formation: $JssorSlideshowFormations$.$FormationStraight, $Easing: {$Left: $Jease$.$InOutQuart, $Opacity: $Jease$.$Linear}, $Opacity: 2, $ZIndex: -10, $Brother: {$Duration: 800, x: 1, $Delay: 40, $Cols: 6, $Formation: $JssorSlideshowFormations$.$FormationStraight, $Easing: {$Left: $Jease$.$InOutQuart, $Opacity: $Jease$.$Linear}, $Opacity: 2, $ZIndex: -10, $Shift: -60}},
            {$Duration: 500, $Delay: 12, $Cols: 10, $Rows: 5, $Clip: 15, $SlideOut: true, $Formation: $JssorSlideshowFormations$.$FormationSwirl, $Easing: $Jease$.$OutQuad, $Opacity: 2},
            {$Duration: 400, $Delay: 50, $Rows: 7, $Clip: 4, $Formation: $JssorSlideshowFormations$.$FormationStraight},
            {$Duration: 500, $Delay: 12, $Cols: 10, $Rows: 5, $Clip: 15, $Formation: $JssorSlideshowFormations$.$FormationStraightStairs, $Easing: {$Clip: $Jease$.$InSine}, $Opacity: 2, $Assembly: 2050},
            {$Duration: 500, x: -1, $Delay: 40, $Cols: 10, $Rows: 5, $SlideOut: true, $Easing: {$Left: $Jease$.$InCubic, $Opacity: $Jease$.$OutQuad}, $Opacity: 2},
            {$Duration: 500, $Delay: 40, $Cols: 10, $Rows: 5, $Clip: 15, $SlideOut: true, $Easing: $Jease$.$OutQuad, $Opacity: 2},
            {$Duration: 600, y: -1, $Cols: 12, $Formation: $JssorSlideshowFormations$.$FormationStraight, $ChessMode: {$Column: 12}, $Easing: $Jease$.$InCubic, $Opacity: 2},
            {$Duration: 600, $Delay: 40, $Cols: 16, $Clip: 1, $Move: true, $Formation: $JssorSlideshowFormations$.$FormationCircle, $Easing: $Jease$.$InBounce, $Assembly: 264},
            {$Duration: 200, x: -1, y: 1, $Delay: 50, $Cols: 10, $Rows: 5, $Formation: $JssorSlideshowFormations$.$FormationStraightStairs, $Easing: {$Left: $Jease$.$InQuart, $Top: $Jease$.$InQuart, $Opacity: $Jease$.$Linear}, $Opacity: 2},
        ];

        var jssor_1_options = {
            $AutoPlay: 1,
            $SlideDuration: 800,
            $SlideEasing: $Jease$.$OutQuint,
            $Cols: 1,
            $Align: 0,
            $CaptionSliderOptions: {
                $Class: $JssorCaptionSlideo$,
                $Transitions: jssor_1_SlideoTransitions
            },
            $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
            },
            $SlideshowOptions: {
                $Class: $JssorSlideshowRunner$,
                $Transitions: jssor_1_SlideoTransitions,
                $TransitionsOrder: 0,
            }
        };

        var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

        /*#region responsive code begin*/

        var MAX_WIDTH = 3000;

        function ScaleSlider() {
            var containerElement = jssor_1_slider.$Elmt.parentNode;
            var containerWidth = containerElement.clientWidth;

            if (containerWidth) {

                var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                jssor_1_slider.$ScaleWidth(expectedWidth);
            } else {
                window.setTimeout(ScaleSlider, 30);
            }
        }

        ScaleSlider();

        $(window).bind("load", ScaleSlider);
        $(window).bind("resize", ScaleSlider);
        $(window).bind("orientationchange", ScaleSlider);
        /*#endregion responsive code end*/
    });

</script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
</body>
</html>
