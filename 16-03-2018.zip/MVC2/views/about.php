<?php
    $assets_url = ASSETS_URL;
?>
    <body>
        <div class="wap container-fluid">
        </div>      
        <img src="<?php echo ASSETS_URL; ?>/image/inner-banner.jpg" alt="Banner" class="img-responsive banner"/>
        <div class="container-fluid padding5">
            <div class="container">
                <h2 class="about">About Us</h2>
                <div class="row">
                    <div class="col-lg-9">
                        <div>
                            <h1 class="article1">&lt;h1&gt; display style</h1>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p> 
                            <h2 class="article2">&lt;h2&gt;display style</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>                        
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <video class="video" controls>
                                    <source src="<?php echo ASSETS_URL; ?>image/video.mp4" type="video/mp4">
                                    <source src="<?php echo ASSETS_URL; ?>image/video.ogg" type="video/ogg">
                                </video>
                                <h3 class="list">&lt;h3&gt;display style</h3>
                                <ul type="disc">
                                    <li>Listing 1</li>
                                    <li>Listing 2</li>
                                    <li>Listing 3</li>
                                    <li>Listing 4</li>
                                </ul>  
                            </div>
                            <div class="col-lg-6">
                                <img src="<?php echo ASSETS_URL; ?>image/cms-img2.jpg" alt="cms-img2" class="img-responsive"/>
                                <h3 class="list">&lt;h3&gt;display style</h3>
                                <ul type="disc">
                                    <li>Listing 1</li>
                                    <li>Listing 2</li>
                                    <li>Listing 3</li>
                                    <li>Listing 4</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-12 padding">
                            <h2>&lt;h2&gt;display style</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        </div>
                        <div class="row">
                            <div class="col-lg-4">
                                <img src="<?php echo ASSETS_URL; ?>image/cms-img3.jpg" alt="cms-3" class="img-responsive">
                                <h4 class="h4_font">&lt;h4&gt;display style</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
                            </div>
                            <div class="col-lg-4">
                                <img src="<?php echo ASSETS_URL; ?>image/cms-img4.jpg" alt="cms-4" class="img-responsive">
                                <h4 class="h4_font">&lt;h4&gt;display style</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
                            </div>
                            <div class="col-lg-4">
                                <img src="<?php echo ASSETS_URL; ?>image/cms-img5.jpg" alt="cms-5" class="img-responsive">
                                <h4 class="h4_font">&lt;h4&gt;display style</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
                            </div>
                        </div>    
                        <div class="row">
                            <div class="col-lg-12">
                                <h2>&lt;h2&gt;display style</h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <img src="<?php echo ASSETS_URL; ?>image/cms-img6.jpg" alt="cms-6" class="img-responsive">
                                <h5 class="subimg1_ds">&lt;h5&gt;display style</h5>
                                <ol type="i">
                                    <li>Listing 1</li>
                                    <li>Listing 2</li>
                                    <li>Listing 3</li>
                                    <li>Listing 4</li>
                                </ol>   
                            </div>
                            <div class="col-lg-6">
                                <img src="<?php echo ASSETS_URL; ?>image/cms-img7.jpg" alt="cms-7" class="img-responsive">
                                <h5 class="subimg1_ds">&lt;h6&gt;display style</h5>
                                <ol type="i">
                                    <li>Listing 1</li>
                                    <li>Listing 2</li>
                                    <li>Listing 3</li>
                                    <li>Listing 4</li>
                                </ol>   
                            </div>
                        </div>    
                    </div>
                    <div class="col-lg-3">
                        <div>
                            <a href="#"><img src="<?php echo ASSETS_URL; ?>image/promo1.jpg" alt="add" class="img-responsive padding4"/></a>
                            <a href="#"><img src="<?php echo ASSETS_URL; ?>image/promo2.jpg" alt="add" class="img-responsive padding4"/></a>
                        </div>
                    </div>

                </div>        
            </div>
        </div>
        <button type="button" class="top_arrow" id="top" onclick="gototop();"><object type="image/svg+xml" data="<?php echo ASSETS_URL; ?>image/up-arrow-white.svg" height="15px" width="15px">
            </object></button>

    </body>
</html>