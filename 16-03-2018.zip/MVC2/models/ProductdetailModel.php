<?php //
//$assets_url = ASSETS_URL;
//class ProductdetailModel extends basemodel {
//    /* Table which is mapped to current model */
//    function getProductDetail() {
//        
//        $query = "select i.id,i.name,i.price,i.is_trending,im.item_id,im.item_image_url from item i
//		  left join item_images im on im.item_id=i.id where im.is_primary=1 LIMIT 9";
//        return $this->getResultArray($this->_db->query($query));
//       }
//    function getProduct($id) {
//        
//        $query = "select i.name,i.price,i.id,i.is_trending,i.sku,i.category_id,i.color_id,i.short_desc,i.description,i.delivery_desc,i.shipping_desc,i.sizeguide_desc,im.item_id,im.item_image_url from item i
//		  left join item_images im on im.item_id=i.id 
//		  where i.id=$id and is_primary=1";
//        return $this->getResultArray($this->_db->query($query));
//       } 
//       
//       public function item_size($id){
//     	$query="select at_op.value
//		from item_options i_o
//		left join attributes_options at_op on at_op.id=i_o.ao_id
//		where i_o.item_id=$id";
//		return $this->getResultArray($this->_db->query($query));
//	    }
//    }
?>
