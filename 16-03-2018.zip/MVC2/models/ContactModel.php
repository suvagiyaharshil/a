<?php

class ContactModel extends basemodel {
    /* Table which is mapped to current model */

    public function contact($data) {
        $this->processInput($data);
        if (isset($_POST['contact'])) {
            $message = "name:" . $this->data['name'];
            $message .= "<br/>email:" . $this->data['email'];
            $message .= "<br/>subject:" . $this->data['subject'];
            $message .= "<br/>message:" . $this->data['message'];
            //echo $message;
            $email = "harshil.suvagiya@internal.mail";
            $subject = "Contact Form";
            $retval = mail($email, $subject, $message);
            header("location:contact");
        }
    }
}
?>