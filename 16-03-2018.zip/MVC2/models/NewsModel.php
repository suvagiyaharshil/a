<?php

class NewsModel extends basemodel {
    /* Table which is mapped to current model */

    public function newsInsert($data) {
        $prevois = $_SERVER['HTTP_REFERER'];
        $this->processInput($data);
        if (isset($_POST['news'])) {
            
            $new_email = $this->data['email'];
            if (empty($new_email)) {
                echo "window.location.replace(\"$prevois\")";
                die();
            }
            $sql = "select * from newsletter_subscriber where email='" . $new_email . "'";
            $result = mysqli_query($this->_db, $sql);
            $row = $result->fetch_array();
            $count = mysqli_num_rows($result);

            if ($count == 0) {
                $sql1 = "insert into newsletter_subscriber(email) values('$new_email')";
                $this->_db->query($sql1);
                $subject = "Newsletter Subscriber";
                $message = "Thank You For Newsletter Subscrib";
                $retval = mail($new_email, $subject, $message);
                $subject1 = "Newsletter Subscriber";
                $message1 = "$new_email Is New Newsletter Subscriber";
                $headers = "FROM: '$new_email'";
                $retval1 = mail("harshil.suvagiya@internal.mail", $subject1, $message1, $headers);
                echo "<script>window.location.replace(\"$prevois\")</script>";
            } else {
                echo "<script>alert('email are already registered');window.location.replace(\"$prevois\")</script>";
            }
        }
    }
}
?>