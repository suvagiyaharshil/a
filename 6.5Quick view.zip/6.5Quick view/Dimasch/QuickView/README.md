# The Quick View extension for magento2
Clicking at product opened a popup with it's information and options + add to cart button

## Demo screenshots
![Catalog listing](docs/listing.png)
