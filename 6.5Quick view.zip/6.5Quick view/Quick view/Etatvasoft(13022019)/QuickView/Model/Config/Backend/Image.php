<?php

namespace Etatvasoft\Quickview\Model\Config\Backend;

class Image extends \Magento\Config\Model\Config\Backend\Image
{
    /**
     * The tail part of directory path for uploading
     *
     */
    const UPLOAD_DIR = 'app\code\Etatvasoft\QuickView\view\adminhtml\web\images\default'; // Folder save image

    /**
     * Return path to directory for upload file
     *
     * @return string
     * @throw \Magento\Framework\Exception\LocalizedException
     */
    public function _getUploadDir()
    {
        return self::UPLOAD_DIR;
    }

    /**
     * Makes a decision about whether to add info about the scope.
     *
     * @return boolean
     */
    public function _addWhetherScopeInfo()
    {
        return true;
    }

    /**
     * Getter for allowed extensions of uploaded files.
     *
     * @return string[]
     */
    public function _getAllowedExtensions()
    {
        return ['jpg', 'jpeg', 'gif', 'png', 'svg'];
    }
}
