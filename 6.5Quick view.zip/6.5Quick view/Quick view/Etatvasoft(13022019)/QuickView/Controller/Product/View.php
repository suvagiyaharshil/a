<?php
namespace Etatvasoft\QuickView\Controller\Product;

use Magento\Catalog\Controller\Product\View as CatalogView;

class View extends CatalogView
{
   
    const DETAIL_ENABLE = 'tatva_quickview/quickview/detail_enable';
    public function execute()
    {
        $isActive = $this->_objectManager->create('Etatvasoft\Quickview\Helper\Data')->getConfig(self::DETAIL_ENABLE);
        if ($isActive==0) {
            if ($this->getRequest()->getParam("iframe")) {
                $layout = $this->_view->getLayout();
                $layout->getUpdate()->addHandle('quickview_product_view');
            }
        } else {
            if ($this->getRequest()->getParam("iframe")) {
                $layout = $this->_view->getLayout();
                $layout->getUpdate()->addHandle('quickview_product_view_detail');
            }
        }

        return parent::execute();
    }
}
