var config = {
    map: {
        '*': {
            colorBox: 'Script_QuickView/js/jquery.colorbox-min.min',
            script_quickview: 'Script_QuickView/js/script-quickview'
        }
    },
    shim: {
        colorBox: {
            deps: ['jquery']
        }
    }
};
