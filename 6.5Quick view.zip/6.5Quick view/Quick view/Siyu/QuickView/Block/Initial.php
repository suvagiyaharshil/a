<?php
namespace Siyu\QuickView\Block;

class Initial extends \Magento\Framework\View\Element\Template
{
}