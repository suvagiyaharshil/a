<?php

namespace Etatvasoft\Quickview\Model\Config\Backend;

use Magento\Framework\Module\Dir;

class Image extends \Magento\Config\Model\Config\Backend\Image
{
    protected $moduleReader;

    public function __construct(
        \Magento\Framework\Module\Dir\Reader $reader,
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Config\ScopeConfigInterface $config,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\MediaStorage\Model\File\UploaderFactory $uploaderFactory,
        \Magento\Config\Model\Config\Backend\File\RequestData\RequestDataInterface $requestData,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->moduleReader = $reader;
        parent::__construct($context, $registry, $config, $cacheTypeList, $uploaderFactory, $requestData, $filesystem, $resource, $resourceCollection, $data);
    }

    const MODULE_VIEW_DIR = 'view';

    public function _getUploadDir()
    {   
        $path=$this->moduleReader->getModuleDir(Dir::MODULE_VIEW_DIR, 'Etatvasoft_QuickView');
        $path=$path.'/adminhtml/web/images/default';
        return $path;
    }

    public function _addWhetherScopeInfo()
    {
        return true;
    }

    public function _getAllowedExtensions()
    {
        return ['jpg', 'jpeg', 'gif', 'png', 'svg'];
    }
}
