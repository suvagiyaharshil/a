Magento 2 Script Base Module

# Installation Guide

````
composer require scriptua/magento2-base
bin/magento module:enable Script_Base
bin/magento setup:upgrade
````

