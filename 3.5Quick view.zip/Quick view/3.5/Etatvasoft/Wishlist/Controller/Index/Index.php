<?php

namespace Etatvasoft\Wishlist\Controller\Index;
use Magento\Catalog\Api\CategoryRepositoryInterface;

class Index extends \Magento\Framework\App\Action\Action {

	protected $_itemFactory;

	public function __construct(
        \Magento\Wishlist\Model\ItemFactory $ItemFactory,
        \Magento\Framework\App\Action\Context $context,
        array $data = []
    ){
        $this->_itemFactory = $ItemFactory;
        parent::__construct($context, $data);
    }

	public function execute() {
		$params = $this->getRequest()->getPost();
		$params = (array) $params;
		$item = $this->_itemFactory->create()->getCollection();
		$item->setOrder('added_at', 'DESC');
		$item->getSelect()->limit(1);
		foreach ($item->getData() as $value) {
			error_log(print_r($value,true),3,'var/log/category.log');
			$value['title']=$params['title'];
			error_log(print_r($value,true),3,'var/log/category1.log');
		}
		error_log(print_r($item->getData(),true),3,'var/log/category2.log');
		$item->setData($item->getData());
		$item->save();
	}

}