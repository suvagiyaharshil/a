var config = {
    map: {
        '*': {
            magnificPopup: 'Etatvasoft_QuickView/js/lib/jquery.magnific-popup',
            quickView: 'Etatvasoft_QuickView/js/quickview'
        }
    },
    shim: {
        magnificPopup: {
            deps: ['jquery']
        }
    }
};
