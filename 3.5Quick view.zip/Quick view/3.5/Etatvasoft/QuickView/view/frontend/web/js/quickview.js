
define([
    'jquery',
    'mage/translate',
    'mage/url',
    'magnificPopup'
], function ($, $t, url) {
    "use strict";

    $.widget('etatvasoft.QuickView', {
        options: {
            baseUrl: '/',
            popupTitle: $t('Quick View'),
            itemClass: '.products.grid .item.product-item, .products.list .item.product-item',
            btnLabel: $t('Quick View'),
            btnContainer: '.product-item-info',
            handlerClassName: 'quick-view-button'
        },
        _create: function () {
            if (!$('body').hasClass('catalog-product-view')) {
                this._initialButtons(this.options);
                this._bindPopup(this.options);
            }
        },
        _initialButtons: function (config) {
            $(config.itemClass).not(".product-item-widget").each(function () {
                if (!$(this).find('.' + config.handlerClassName).length) {
                    var groupName = $(this).parent().attr('class').replace(' ', '-');
                    var productId = $(this).find('.price-final_price').data('product-id');
                    if (typeof productId !== 'undefined' && productId !== undefined && productId !== null) {
                        var url = config.baseUrl + 'quickview/catalog_product/view/id/' + productId;
                        
                        var btnQuickView = '<div class="quick-view-btn-container">';
                        btnQuickView += '<a rel="' + groupName + '" class="' + config.handlerClassName + '" href="' + url + '"';
                        btnQuickView += ' title="' + config.popupTitle + '"';
                        btnQuickView += ' >';
                        btnQuickView += '<img src="https://quick-view.demo.mageplaza.com/pub/static/version1547714808/frontend/Magento/luma/en_US/Mageplaza_QuickView/media/btn-icon.svg"></img></a>';
                        btnQuickView += '</div>';
                        $(this).find(config.btnContainer).prepend(btnQuickView);
                    }
                }
            });
        },
        _bindPopup: function (config) {
            var self = this;
            $('.' + config.handlerClassName).each(function () {
                $(this).magnificPopup({
                    type: 'ajax',
                    closeOnContentClick: false,
                    closeMarkup: '<button title="Close (Esc)" type="button"></button>',
                    callbacks: {
                        ajaxContentAdded: function() {
                            // Ajax content is loaded and appended to DOM
                            $('.mfp-content').trigger('contentUpdated');
                        }
                    }
                });
            });
        }
    });

    return $.etatvasoft.QuickView;
});
