var config = {
    map: {
        '*': {
            magnificPopup: 'Dimasch_QuickView/js/lib/jquery.magnific-popup',
            quickView: 'Dimasch_QuickView/js/quickview'
        }
    },
    shim: {
        magnificPopup: {
            deps: ['jquery']
        }
    }
};
