<?php
namespace Siyu\QuickView\Block;

class Anchor extends \Magento\Framework\View\Element\Template
{
}