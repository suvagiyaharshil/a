<?php
namespace Tatva\Quickview\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{   

    public function getConfig($config_path)
    {
        return $this->scopeConfig->getValue(
            $config_path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getTheme()
    {   
        $theme_id=$this->getConfig('design/theme/theme_id');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('theme');
        $sql = "Select theme_path  FROM " . $tableName ." where theme_id=".$theme_id;
        $result = $connection->fetchAll($sql); 
        return $result['theme_path'];
    }
}