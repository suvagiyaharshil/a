<?php
namespace Tatva\QuickView\Controller\Product;
use Magento\Catalog\Controller\Product\View as CatalogView;
class View extends CatalogView
{
    public function execute()
    {	
    	$isActive = $this->_objectManager->create('Tatva\Quickview\Helper\Data')->getConfig('tatva_quickview/quickview/detail_enable');
    	if($isActive==0){
	        if ($this->getRequest()->getParam("iframe")) {
	            $layout = $this->_view->getLayout();
	            $layout->getUpdate()->addHandle('quickview_product_view');
	        }
    	}else{
            if ($this->getRequest()->getParam("iframe")) {
                $layout = $this->_view->getLayout();
                $layout->getUpdate()->addHandle('quickview_product_view_detail');
            }
        }
        return parent::execute();
    }
}
