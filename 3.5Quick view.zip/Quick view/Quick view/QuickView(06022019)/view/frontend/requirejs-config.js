var config = {
    map: {
        '*': {
            magnificPopup: 'Tatva_QuickView/js/lib/jquery.magnific-popup',
            quickView: 'Tatva_QuickView/js/quickview'
        }
    },
    shim: {
        magnificPopup: {
            deps: ['jquery']
        }
    }
};
