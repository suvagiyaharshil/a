Magento 2 Product QuickView Module

# Installation Guide
````
composer require scriptua/magento2-quickview
bin/magento module:enable Script_QuickView
bin/magento setup:upgrade
````
