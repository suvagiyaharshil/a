<?php
namespace Etatvasoft\Quickview\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    public function getConfig($configPath)
    {
        return $this->scopeConfig->getValue(
            $configPath,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getTheme()
    {
        $themeId=$this->getConfig('design/theme/theme_id');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('theme');
        $sql = "Select theme_path  FROM " . $tableName ." where theme_id=".$themeId;
        $result = $connection->fetchOne($sql);
        return $result;
    }
}
