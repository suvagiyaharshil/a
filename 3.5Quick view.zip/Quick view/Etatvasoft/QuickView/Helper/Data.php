<?php
namespace Etatvasoft\Quickview\Helper;
use Magento\Framework\App\Helper\Context;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    protected $scopeConfig;
    protected $storeManager;
    protected $themeProvider;

    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scope,
        \Magento\Store\Model\StoreManagerInterface $store,
        \Magento\Framework\View\Design\Theme\ThemeProviderInterface $theme,
        Context $context
    )
    {   
        $this->scopeConfig = $scope;
        $this->storeManager = $store;
        $this->themeProvider = $theme;
        parent::__construct($context);
    }


    public function getConfig($configPath)
    {
        return $this->scopeConfig->getValue(
            $configPath,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getTheme()
    {   

        $themeId = $this->scopeConfig->getValue(
            \Magento\Framework\View\DesignInterface::XML_PATH_THEME_ID,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->storeManager->getStore()->getId()
        );

        $theme = $this->themeProvider->getThemeById($themeId);
        return $theme->getThemePath();
    }
}
