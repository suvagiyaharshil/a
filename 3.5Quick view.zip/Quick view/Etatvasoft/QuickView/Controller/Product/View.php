<?php
namespace Etatvasoft\QuickView\Controller\Product;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Catalog\Controller\Product\View as CatalogView;

class View extends CatalogView
{
    public $scopeConfig;

    public function __construct(
        Context $context,
        \Magento\Catalog\Helper\Product\View $viewHelper,
        \Magento\Framework\Controller\Result\ForwardFactory $resultForwardFactory,
        PageFactory $resultPageFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
        parent::__construct($context, $viewHelper, $resultForwardFactory, $resultPageFactory);
    }

    const DETAIL_ENABLE = 'tatva_quickview/quickview/detail_enable';
    public function execute()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $isActive = $this->scopeConfig->getValue(self::DETAIL_ENABLE, $storeScope);
        if ($isActive==0) {
            if ($this->getRequest()->getParam("iframe")) {
                $layout = $this->_view->getLayout();
                $layout->getUpdate()->addHandle('quickview_product_view');
            }
        } else {
            if ($this->getRequest()->getParam("iframe")) {
                $layout = $this->_view->getLayout();
                $layout->getUpdate()->addHandle('quickview_product_view_detail');
            }
        }

        return parent::execute();
    }
}
