<?php

class About extends BaseController {

    public function index() {
        $this->load_view('header');
        $this->load_view('about');
        $this->load_view('footer');
    }

}
