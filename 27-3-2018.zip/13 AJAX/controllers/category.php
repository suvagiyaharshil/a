<?php

class category extends BaseController {

    public function index() {
        $this->load_view('header');
        $test = $this->test(0);
        $this->load_view('category');
        $this->load_view('footer');
    }

    public function insertcategory($data) {
        $this->load_model('CategoryModel');
        $allCatgory = $this->categorymodel->insertcat($_POST);
    }

    function test($Level = 0,$sub = 0, $prefix = '') {
       $maincat = '';
        $this->load_model('CategoryModel');
        $allCategory = $this->categorymodel->getCategory($Level);
        if (!empty($allCategory)) {
            foreach ($allCategory as $value) {
                if($sub == 1)
                {
                 $maincat .= "<option value=" . $value['id'] . ">" . $prefix .$value['name'] . "</option>";   
                } else {
                 $maincat .= "<option value=" . $value['id'] . ">" . $value['name'] . "</option>";   
                }
                $maincat .= $this->test($value['id'],1,$prefix . '----');
            }
        }
        return $maincat;
    }
}
