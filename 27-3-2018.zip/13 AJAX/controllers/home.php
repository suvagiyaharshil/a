<?php

class Home extends BaseController {

    public function index() {
        $this->load_view('header');
        $this->load_view('home');
        $this->load_view('footer');
    }
}
