<?php

class Contact extends BaseController {

    public function index() {
        $this->load_view('header');
        if (isset($_POST['contact'])) {
            $this->load_model('ContactModel');
            $this->contactmodel->contact($_POST);
        }
        $this->load_view('contact');
        $this->load_view('footer');
    }

}
