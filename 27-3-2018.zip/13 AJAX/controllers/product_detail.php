<?php class Product_detail extends BaseController {

    /**
     * @author Tatvasoft
     * Default method of Home controller and load header,main content,footer view.
     * 	 
     */
    public function index($id) {
        $this->load_model("ProductList");
        $product['item_detail'] = $this->productlist->getitem($id);
        $product['item_size']=$this->productlist->item_size($id);
        $this->load_view('header');
        $this->load_view('productdetail',$product);
        if(isset($_POST['news'])) {
        $this->load_model('NewsModel');    
        $this->newsmodel->newsInsert($_POST);    
        }
        $this->load_view('footer');
    }
    public function addwislist(){
        $this->load_model("ProductList");
        $id=$_POST['id'];
        $product=$this->productlist->addtowishlist($id);
        if($product==true)
        {
            echo json_encode(array('status' => 1, 'msg' => 'success'));
        }
        else{
            echo json_encode(array('status' => 2, 'msg' => 'falls'));

        }
    }
    
}