<?php

class Login extends BaseController {

    public function index() {
        if (!checkIfLogin()) {
            $this->load_model("LoginModel");
            if ($this->loginmodel->authenticate($_POST['username'], $_POST['password'])) {
                echo json_encode(array('status' => 1, 'msg' => 'You have successfully logged-in.'));
            } else {
                echo json_encode(array('status' => 0, 'msg' => 'Email-id or password is incorrect.'));
            }
        } else {
            echo json_encode(array('status' => 2, 'msg' => 'You have already logged-in.'));
        }
    }

}
