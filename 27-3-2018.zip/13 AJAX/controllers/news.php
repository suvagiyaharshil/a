<?php

class News extends BaseController {

    public function news_form() {
        if (isset($_POST['news'])) {
            $this->load_model('NewsModel');
            $this->newsmodel->newsInsert($_POST);
        }
    }

}

?>