<?php

class Register extends BaseController {

    public function index() {
        if (!checkIfLogin()) {
            $validationErrors = array();
            if (isset($_POST['register_submit'])) {
                $this->load_model("RegisterModel");
                if ($this->registermodel->insert($_POST)) {
                    $this->load_model("LoginModel");
                    if ($this->loginmodel->authenticate($this->registermodel->data['email'], $this->registermodel->data['password'])) {
                        $this->redirect('home/index');
                    }
                } else {
                    // insert fail due to some validation errors
                    $validationErrors = $this->registermodel->getErrors();
                }
            }
            $this->load_view('header');
            $this->load_view('user/register', array('validationErrors' => $validationErrors));
            $this->load_view('footer');
        } else {
            echo "<script>window.location.replace('profile')</script>";
        }
    }

    public function emailvalidate() {
        $this->load_model("RegisterModel");
        if ($this->registermodel->checkEmailExist($_POST['email'])) {
            echo "Email-id already registered.";
        } else {
            
        }
    }

    public function uservalidate() {
        $this->load_model("RegisterModel");
        if ($this->registermodel->checkUsernameExist($_POST['username'])) {
            echo "Username already registered.";
            exit;
        } else {
            
        }
    }

}
