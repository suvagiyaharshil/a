<?php

class product_display extends BaseController {

    public function index() {
        $this->load_model('ProductList');
        $item_ids = Array();
        $limit = $_POST['limit'];

        $sort = $_POST['sort'];
        if ($sort != 0) {
            $result = $this->productlist->showsortImg($limit, $sort);
            $rows = mysqli_num_rows($result);
        } else {
            $result = $this->productlist->showImg($limit);
            $rows = mysqli_num_rows($result);
        }
        if ($limit > $rows) {
            ?>
            <script>
                $("#more_product_btn").hide();
                $("#no_more_data").show();
            </script>
            <?php
        } else {
            
        }
        ?>

        <?php
        while ($value = $result->fetch_assoc()) {
            ?>

            <section class="col-sm-4 img1">
                <div class="bg">
                    <a href="<?php echo SITE_URL; ?>product/detail/<?php echo $value['id']; ?>"><img class="img-responsive mainimg" src="<?php echo ASSETS_URL ?>image/<?php echo $value['item_images_url']; ?>.jpg" alt="alt"></a>
                </div>    
                <div class="overlay">
                    <center class="product_button"><a href="<?php echo SITE_URL; ?>product/detail/<?php echo $value['id']; ?>"<button type="button" class="btn btn-default middle">ADD TO CART</button></a></center>
                </div>            
                <div class="caption"><article class="artical_text"><?php echo $value['name']; ?><br/>
                        <b class="prize_color"><?php echo $value['price']; ?></b></article>
                </div>   
            </section>
            <?php
        }
    }

}
