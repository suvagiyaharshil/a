<?php
/**
 * @author Tatvasoft
 * All Global constant will be declare here.
 *
 */
error_reporting(0);
$error_display = 0;
if($error_display) {    
    ini_set('display_errors',0);
    error_reporting(E_ALL); // & ~E_NOTICE & ~E_WARNING
}else{
    error_reporting(0);
}
session_start();

define('SITE_NAME', ''); // Name of route folder
define('SITE_URL','http://'.$_SERVER['HTTP_HOST'].'/'.SITE_NAME);

define('SITE_PATH', $_SERVER["DOCUMENT_ROOT"]. '/'.SITE_NAME);
define('INCLUDE_PATH', SITE_PATH . 'include/');
define('ASSETS_URL', SITE_URL . 'public/');
define('UPLOAD_URL', SITE_URL . 'public/upload/');

//defines the database username and password.
define("DB_HOST", "");
define("DB_PORT", "");
define("DB_USER_NAME", "");
define("DB_PASSWORD", "");
define("DB_NAME", "");

define('DEFAULT_CONTROLLER', 'home');
define('DEFAULT_ACTION', 'index');
?>