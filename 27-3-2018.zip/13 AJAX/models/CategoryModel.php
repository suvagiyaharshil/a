<?php

class CategoryModel extends basemodel {
    
    function getCategory($level = 0) {
        $sql = "SELECT id, name, parent_id FROM category WHERE 1 AND parent_id = $level ORDER BY id ASC";      
        $rows = $this->getResultArray($this->_db->query($sql));
        return $rows;
    }

    function insertcat($data) {
        $this->processInput($data);
        $category = $this->data['category'];
        $catname = $this->data['catname'];
        $sql1 = "insert into category(name,parent_id) values('$category','$catname')";
        $result = $this->_db->query($sql1);
        if ($result == 1) {
            echo "<script>window.location.replace('/category');</script>";
        } else {
            echo "<script>alert('category is not added');</script>";
        }
    }
}
?>
