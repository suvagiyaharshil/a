<?php

class RegisterModel extends basemodel {
    /* Table which is mapped to current model */

    private $_table = 'user';

    /**
     * @author Tatvasoft
     * Check unique email id .
     * 
     * @params email id
     * @return true if email id is already exist else false.
     */
    public function checkEmailExist($email) {
        //echo $email;        exit();
        $sql = "SELECT id FROM " . $this->_table . " where email='" . $email . "'";
        $result = mysqli_query($this->_db, $sql);

        if ($result->num_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @author Tatvasoft
     * Check unique username.
     * 
     * @params username
     * @return true if username is already exist else false.
     */
    public function checkUsernameExist($username) {

        $sql = "SELECT id FROM " . $this->_table . " where username='" . $username . "'";
        $result = mysqli_query($this->_db, $sql);
        if ($result->num_rows > 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @author Tatvasoft
     * Check if user has read terms and condition.
     * 
     * @params is_agree field
     * @return true if user has not read terms and condition with validation message else false.
     */
    public function isAgreed($data) {

        if (!isset($data['is_agree'])) {
            $this->validationError['is_agree'] = 'Please agree terms and Condition Before Procedure further';
        }

        if (empty($data['is_agree'])) {
            $this->validationError['is_agree'] = 'Please agree terms and Condition Before Procedure further';
        }
        if (empty($this->validationError)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @author Tatvasoft
     * validate user data before save in database.
     * 
     * @params user information
     * @return true if any of user data is not valid  or already exist in system else false.
     */
    public function validate($data) {
        $this->processInput($data);
        $this->isAgreed($data);
        if (!preg_match('/^[A-z]+$/', $this->data['username'])) {
            $this->validationError['username'] = "enter your name The lenght of username must be atleast eight alphabetic";
        }
        if (!preg_match('/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/', $this->data['mobile'])) {
            $this->validationError['mobile'] = "";
        }
        if (!preg_match('/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/', $this->data['email'])) {
            $this->validationError['email'] = "Please enter valid e-mail";
        }
        if (!preg_match('/^[A-z]+$/', $this->data['firstname'])) {
            $this->validationError['firstname'] = "In firstname only allow alphabetic";
        }
        if (!preg_match('/^(?=(.*[A-Z]){2})(?=.*?[0-9])(?=.*?[!@#$%^&*])[a-zA-Z0-9!@#$%\^&\*]{4,}$/', $this->data['password'])) {
            $this->validationError['password'] = "Password has atleast one number,two capital letter,atleast one symbol";
        }
        if (!preg_match('/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/', $this->data['mobile'])) {
            $this->validationError['mobile'] = "You have to enter valid numbers";
        }
        if (!preg_match('/^[0-9]*$/', $this->data['phone'])) {
            $this->validationError['phone'] = "You have to enter valid numbers";
        }
        if (!isset($_POST['all']) && !isset($_POST['option1']) && !isset($_POST['option2']) && !isset($_POST['option3']) && !isset($_POST['other']))
        {
            $this->validationError['interest'] = "Please select interest";
        }else if (isset($_POST['other']) && empty($this->othtxt)) {
            $this->validationError['interest'] = "Please enter your interest";
        }  
        if ($this->validationError) {

            if(isset($_POST['all'])){
            $this->validationError['inputAllVal'] = isset($_POST['all']);
            }

            if(isset($_POST['option1'])){
            $this->validationError['inputOneVal'] = isset($_POST['option1']);
            }

            if(isset($_POST['option2'])){
            $this->validationError['inputTwoVal'] = isset($_POST['option2']);
            }

            if(isset($_POST['option3'])){
            $this->validationError['inputThreeVal'] = isset($_POST['option3']);
            }

            if(isset($_POST['other'])){
            $this->validationError['inputOtherVal'] = isset($_POST['other']);
            }
        }         

        if (!preg_match('/^[A-z]+$/', $this->data['lastname'])) {
            $this->validationError['lastname'] = "In lastname only allow alphabetic";
        }
        if (empty($this->validationError)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @author Tatvasoft
     * Insert record in database .
     * 
     * @params user information.
     * @return true if record insert successfully else false.
     */
    public function insert($data) {

//        if ($this->validate($data)) {
//            $sql = "INSERT INTO " . $this->_table . " (username, firstname,lastname, email, gender, password,mobile_number, phone_number,is_active)
//			VALUES ('" . $this->data['username'] . "', '" . $this->data['firstname'] . "','" . $this->data['lastname'] . "', '" . $this->data['email'] . "', '" . $this->data['gender'] . "', '" . md5($this->data['password']) . "','" . $this->data['mobile'] . "','" . $this->data['phone'] . "',1)";
//            if ($this->_db->query($sql) === TRUE) {
//                return true;
//            } else {
//                return false;
//            }
//        } else {
//
//            return false;
//        }
        if ($this->validate($data)) {
            // $this->processInput($data);
            $sql = "select email from user where email='" . $this->data['email'] . "' and username!='" . $this->data['username'] . "'";
            $result = mysqli_query($this->_db, $sql);

            $count = mysqli_num_rows($result);
            if ($count == 0) {
                $sql = "insert into user (username,password,firstname,lastname,gender,email,mobile_number,phone_number,is_active)values('" . $this->data['username'] . "','" . md5($this->data['password']) . "','" . $this->data['firstname'] . "','" . $this->data['lastname'] . "','" . $this->data['gender'] . "','" . $this->data['email'] . "','" . $this->data['mobile'] . "','" . $this->data['phone'] . "',1)" or die(mysql_error());
                if (mysqli_query($this->_db, $sql) == TRUE) {
                    $subject = "Register";
                    $user = $this->data['username'];
                    $message = "Welcom: " . $user;
                    $message .= "Thank You For Register";
                    $new_email = $this->data['email'];
                    $retval = mail($new_email, $subject, $message);
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            } else {
                echo "<script>alert('email are registered');</script>";
            }
        } else {

            return false;
        }
    }

}
