<?php
$assets_url = ASSETS_URL;
?>
<body>
    <img src="<?php echo ASSETS_URL; ?>image/inner-banner.jpg" alt="Banner" class="img-responsive banner"/>
    <div class="container-fluid mediabg">
        <div class="container">
            <h2 class="about">Contact Us</h2>
            <div class="row">
                <ol class="breadcrumb mediabg ">
                    <li class="breadcrumb-item"><a href="home" class="mediabg_color">Home</a></li>
                    <li class="breadcrumb-item"><a href="contact" class="active_breadcrumb">Contact Us</a></li>
                </ol>
            </div>
        </div>

    </div>
    <br/><br/>
    <div class="container">
        <div class="row">
            <div class="col-sm-9">
                <form action="" method="post" class="reg_form">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group reg_field">
                                Name
                                <input type="text" class="form-control " name="name" id="name" placeholder="Please enter your name" name="email">
                                <p id="name_error"></p>
                            </div>
                            <div class="form-group reg_field">
                                Email
                                <input type="email" class="form-control" name="email" id="email" placeholder="Please enter your email">
                                <p id="email_error"></p>
                            </div>
                            <div class="form-group reg_field">
                                Subject
                                <input type="text" class="form-control" name="subject" id="subject" placeholder="Please enter your subject">
                                <p id="subject_error"></p> 
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                Message
                                <textarea class="form-control" name="message" id="message"rows="10"></textarea>
                                <p id="message_error"></p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12"><button type="submit" id="contact" name="contact" class="btn btn-default con_form_button">Submit</button></div>
                    </div>
                </form> 

                <div class="col-sm-7 embed-responsive embed-responsive-16by9">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3671.695341808034!2d72.49821031508465!3d23.034955784946778!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e8352e403437b%3A0xdc9d4dae36889fb9!2sTatvaSoft!5e0!3m2!1sen!2sin!4v1516263923933" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
                <div class="col-sm-1"></div>
                <div class="col-sm-4">
                    <h3>Get In Touch</h3>
                    Tatvasoft House,<br/>
                    Rajpath club Road,<br/>
                    Near Shivalik Business Center,<br/>
                    Opp. Golf Academy,<br/>
                    Off S G Road,Ahmedabad,<br/>
                    Gujrat 380054<br/>
                    <br/>
                    Phone: <b class="con_address_color">(03)555 55555</b><br/>
                    Email: <b class="con_address_color">info@tatvasoft.com</b>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="right">
                    <a href="#"><img src="<?php echo ASSETS_URL; ?>/image/promo1.jpg" alt="add" class="img-responsive"/></a><br/>
                    <a href="#"><img src="<?php echo ASSETS_URL; ?>/image/promo2.jpg" alt="add" class="img-responsive"/></a><br/>
                </div>
            </div>
        </div>
    </div>
    <button type="button" class="top_arrow" id="top" onclick="gototop();"><object type="image/svg+xml" data="<?php echo ASSETS_URL; ?>image/up-arrow-white.svg" height="15px" width="15px">
        </object></button>

</body>
</html>