<?php
$assets_url = ASSETS_URL;
?>
<body>
    <div class="wap container-fluid">
    </div>      
    <img src="<?php echo ASSETS_URL; ?>/image/inner-banner.jpg" alt="Banner" class="img-responsive banner"/>
    <div class="container-fluid mediabg">
        <div class="container">
            <h2 class="about">Category</h2>
            <div class="row">
                <ol class="breadcrumb mediabg">
                    <li class="breadcrumb-item"><a href="home" class="mediabg_color">Home</a></li>
                    <li class="breadcrumb-item"><a href="category" class="active_breadcrumb">Category</a></li>
                </ol>
            </div>
        </div>
    </div>
    <div class="container">
        <h2 class="reg_h2">Category</h2>
        <form action="/category/insertcategory" method="post" id="" name="">
            <div class="row">
                <div class="form-group col-lg-6">
                    <label>Category:</label>
                    <select class="form-control" name="catname" id="catname">
                        <?php echo $this->test(0,0);?>
                    </select>        

                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label>Add New Category</label>
                        <input type="text" class="form-control" name="category" id="category" placeholder="Please enter category name">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <button type="submit" class="btn btn-default reg_button reg_submit" name="" id="">Add Category</button>
                </div>
            </div>
        </form>
    </div>    
</body>