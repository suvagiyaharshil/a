<?php
$assets_url = ASSETS_URL;
foreach ($item_detail as $value) {
    $id = $value['id'];
    $name = $value['name'];
    $sku = $value['sku'];
    $qty = $value['qty'];
    $price = $value['price'];
    $short_desc = $value['short_desc'];
    $description = $value['description'];
    $delivery_desc = $value['delivery_desc'];
    $shipping_desc = $value['shipping_desc'];
    $sizeguide_desc = $value['sizeguide_desc'];
    $url_image = $value['item_images_url'];
}
?>
<div class="wap container-fluid">
</div>
<img src="<?php echo $assets_url; ?>image/inner-banner.jpg" alt="Banner" class="img-responsive banner"/>
<div class="container-fluid mediabg">
    <div class="container">
        <div class="row">
            <h2 class="about">T-shirts</h2>

            <ol class="breadcrumb mediabg">
                <li class="breadcrumb-item"><a href="/home" class="mediabg_color">Home</a></li>
                <li class="breadcrumb-item"><a href="/product" class="mediabg_color">Men</a></li>
                <li class="breadcrumb-item"><a href="/product" class="mediabg_color">T-shirts</a></li>
                <li class="breadcrumb-item"><a href="product_detail" class="active_breadcrumb">US Polo Assn FullSleeve Plain T-Shirts for Men</a></li>
            </ol>
        </div>
    </div>
    <div>

    </div>
</div>

<!-- <div class="container cart_alert collapse" id="Wishlistalert" style="border-bottom: none;">
    <div class="row">
               <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <object type="image/svg+xml" data="<?php echo $assets_url; ?>.images/success.svg" height="15px" width="15px">
                    </object>
                    &nbsp;US Polo Assn FullSleeve Plain T-Shirts for Men Was Added To Your Wishlist
                </div>
    </div>   
</div>-->
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <div class="alert alert-success alert-dismissable cart_alert collapse" id="Wishlistalert">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <span><svg width="16" height="16">
                    <image xlink:href="<?php echo $assets_url; ?>image/success.svg" width="16" height="16"/>
                    </svg></span>U.S Polo Assn.Full Sleve Plain T-Shirt for Men has been added to your wishlist.
            </div>
            <div class="alert alert-warning alert-dismissable cart_alert collapse" id="addedWishlistalert">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <span><svg width="16" height="16">
                    <image xlink:href="<?php echo $assets_url; ?>image/warning.svg" width="16" height="16"/>
                    </svg></span>&nbsp;U.S Polo Assn.Full Sleve Plain T-Shirt for Men has been already added to your wishlist.
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-sm-5 padding">
            <div id="jssor_1" style="position:relative;width:980px;height:1380px;overflow:hidden;visibility:hidden;">
                <!--                 Loading Screen -->
                <div data-u="loading" class="jssorl-009-spin" style="position:absolute;width:100%;height:100%;text-align:center;background-color:rgba(0,0,0,0.7);">
                    <img style="margin-top:-19px;position:relative;top:50%;width:38px;height:38px;" src="<?php echo $assets_url; ?>image/spin.svg" />
                </div>
                <div data-u="slides" style="cursor:default;position:relative;width:980px;height:1180px;overflow:hidden;">
                    <?php foreach ($image_slider as $product) { ?>
                        <div data-p="170.00" class="zoom">
                            <img data-u="image" src="<?php echo $assets_url . "image/" . $product['item_images_url'] . "-big.jpg"; ?>" />
    <!--                            <img data-u="image" src="<?php echo $assets_url . "image/" . $product['item_images_url'] . ".jpg"; ?>" id="largeImage" class="img-responsive" data-zoom-image="<?php echo $assets_url . "image/" . $product['item_images_url'] . "-big.jpg"; ?>">-->
                            <img data-u="thumb" src="<?php echo ASSETS_URL . "image/" . $product['item_images_url'] . ".jpg"; ?>"/>
                        </div>
                    <?php } ?>    
                </div>
                <!--                 Thumbnail Navigator -->
                <div data-u="thumbnavigator" class="jssort101" style="position:absolute;bottom:0px;width:980px;height:200px;background-color:#000;" data-autocenter="1" data-scale-bottom="0.75">
                    <div data-u="slides">
                        <div data-u="prototype" class="p" style="width:190px;height:180px;">
                            <div data-u="thumbnailtemplate" class="t"></div>
                            <svg viewbox="0 0 16000 16000" class="cv">
                            <circle class="a" cx="8000" cy="8000" r="3238.1"></circle>
                            <line class="a" x1="6190.5" y1="8000" x2="9809.5" y2="8000"></line>
                            <line class="a" x1="8000" y1="9809.5" x2="8000" y2="6190.5"></line>
                            </svg>
                        </div>
                    </div>
                </div>
                <!--                 Arrow Navigator -->
                <div data-u="arrowleft" class="jssora106" style="width:55px;height:55px;top:520px;left:30px;" data-scale="0.75">
                    <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <circle class="c" cx="8000" cy="8000" r="6260.9"></circle>
                    <polyline class="a" points="7930.4,5495.7 5426.1,8000 7930.4,10504.3 "></polyline>
                    <line class="a" x1="10573.9" y1="8000" x2="5426.1" y2="8000"></line>
                    </svg>
                </div>
                <div data-u="arrowright" class="jssora106" style="width:55px;height:55px;top:520px;right:30px;" data-scale="0.75">
                    <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <circle class="c" cx="8000" cy="8000" r="6260.9"></circle>
                    <polyline class="a" points="8069.6,5495.7 10573.9,8000 8069.6,10504.3 "></polyline>
                    <line class="a" x1="5426.1" y1="8000" x2="10573.9" y2="8000"></line>
                    </svg>
                </div>

            </div>
    <!--<img id="largeImage" src='<?php echo $assets_url; ?>image/small/image1.png' data-zoom-image="<?php echo $assets_url; ?>image/large/image1.jpg"/>-->
        </div>
        <div class="col-sm-7 detail_padding">
            <p class="detail_font_size"><?php echo $name; ?></p>
            <p><?php echo $short_desc; ?></p>
            <p>SKU:<b class="detail_font_bold"><?php echo $sku; ?></b></p>
            <p>Availability:</p>
            <?php echo ($qty == 0) ? ' <p class="avail">Not Available</p>' : '<p class="stock">In stock</p>' ?>
            <p class="detail_color" id="sum" value="120">$<span id="price" value="<?php echo$price; ?>"><?php echo$price; ?></span>.00</p>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="exampleSelect1"><b class="detail_review">*</b>size</label>
                        <label for="exampleSelect1" class="detail_required">*required</label>

                        <select class="form-control dropdown" id="size">
                            <option>-Select Size-</option>
                            <?php
                            foreach ($item_size as $size) {
                                # code...
                                ?>
                                <option value="<?php echo $size['value']; ?>"><?php echo $size['value']; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>    
            </div>
            <div class="row">
                <div class="col-sm-2">
                    <div class="form-group detail_dropdown">
                        <p>Qty:</p>
                        <select class="form-control dropdown" name="qty" id="qty" >
                            <option></option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-2">
                    <input type="hidden" id="iditem" value="<?php echo $id; ?>">
                    <button type="button" id="addtocart1" class="btn btn-default detail_addtocart">
                        <p class="detail_addtocart_bg">Add To Cart</p>

                    </button>
                </div>
                <!--               <div class="col-sm-2">
                                    <a href="<?php echo SITE_URL; ?>/cart/addtocart/<?php echo $id; ?>"><button type="submit" class="btn btn-default detail_addtocart">
                                                <p class="detail_addtocart_bg">Add To Cart</p>
                
                                            </button></a>
                                        </div>-->
            </div>
            <!--                    <p class="detail_wishlist">Add To Wishlist</p>-->
            <!--            <a href="#wishlist" class="detail_wishlist" data-toggle="collapse">Add To Wishlist</a>-->
            <div>
                <input type="hidden" name="itemid" id="itemid" value="<?php echo "$id"; ?>">
                <a id="wishlist" data-toggle="collapse" class="detail_wishlist">Add to Wishlist</a>
            </div>

            <div class="row">	
                <ul  class="nav nav-pills detail_tab">
                    <li class="active">
                        <a  href="#Delivery" data-toggle="tab" class="detail_a">Delivery</a>
                    </li>
                    <li><a href="#Shipping" data-toggle="tab" class="detail_a">Shipping</a>
                    </li>
                    <li><a href="#Sizeguide" data-toggle="tab" class="detail_a">Sizeguide</a>
                    </li>   
                </ul>

                <div class="tab-content clearfix">
                    <div class="tab-pane active detail_padding" id="Delivery">
                        <p><?php echo $delivery_desc; ?></p>
                    </div>
                    <div class="tab-pane detail_padding" id="Shipping">
                        <p><?php echo $shipping_desc; ?></p>
                    </div>
                    <div class="tab-pane detail_padding" id="Sizeguide">
                        <!--                                <div class="table-responsive">          
                                                            <table class="table detail_table">
                                                                <thead class="detail_table_bg">
                                                                    <tr>
                                                                        <th>Size</th>    
                                                                        <th>S</th>
                                                                        <th>M</th>
                                                                        <th>L</th>
                                                                        <th>XL</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <tr>
                                                                        <td>Men</td>
                                                                        <td>7-10</td>
                                                                        <td>10-13</td>
                                                                        <td>13-15</td>
                                                                        <td>15-17</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Women</td>
                                                                        <td>7-9</td>
                                                                        <td>10-12</td>
                                                                        <td>13-14</td>
                                                                        <td>15-16</td>
                                                                    </tr>
                                                                </tbody>
                                                            </table></div>-->

                        <?php echo $sizeguide_desc; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br/>
    <div class="row">
        <ul  class="nav nav-pills detail_tab">
            <li class="active">
                <a  href="#Description" data-toggle="tab" class="detail_a">Product Description</a>
            </li>
            <li><a href="#Review" data-toggle="tab"  class="detail_a">Product's Review</a>
            </li>
            <li><a href="#tab" data-toggle="tab"  class="detail_a">CMS tab</a>
            </li>   
        </ul>

        <div class="tab-content clearfix">
            <div class="tab-pane active detail_padding" id="Description">
                <p><?php echo $description; ?></p>
            </div>
            <div class="tab-pane detail_padding" id="Review">
                <div>    

                    <a data-target="#rating" class="detail_review" data-toggle="collapse">Write a Review</a>
                    <hr class="profile_hr">
                </div>
                <div class="collapse" id="rating">
                    <form action="" method="post">
                        <!--                                <div class="pro_col_star rate-area">
                                                            <object type="image/svg+xml" data="image/star.svg" class="star"></object>
                                                            <object type="image/svg+xml" data="image/star.svg" class="star"></object>
                                                            <object type="image/svg+xml" data="image/star.svg" class="star"></object>
                                                            <object type="image/svg+xml" data="image/star.svg" class="star"></object>
                                                            <object type="image/svg+xml" data="image/star.svg" class="star"></object>
                                                        </div>-->
                        <div class="starRating">
                            <input class="star_rate" id="rating5" type="radio" name="rating" value="5">
                            <label for="rating5">5</label>
                            <input class="star_rate" id="rating4" type="radio" name="rating" value="4">
                            <label for="rating4">4</label>
                            <input class="star_rate" id="rating3" type="radio" name="rating" value="3">
                            <label for="rating3">3</label>
                            <input class="star_rate" id="rating2" type="radio" name="rating" value="2">
                            <label for="rating2">2</label>
                            <input class="star_rate" id="rating1" type="radio" name="rating" value="1">
                            <label for="rating1">1</label>
                        </div><br/><br/>

                        <div class="form-group">
                            <textarea class="form-control" rows="4" id="comment" name="comment"  placeholder="Write A Review"></textarea>
                            <div class="form-group">
                                <input type="hidden" name="rating" id="rating" value="">
                                <input type="hidden" name="itemid" id="itemid" value="<?php echo "$id"; ?>"><br/>
                                <button type="button" name="reviewbtn" id="reviewbtn" class="btn btn-default reg_submit">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>    
                <div id="header_review"></div>
                <div id="description_review"></div>
                <div id="output"><?php
                    foreach ($item_review as $value) {
                        $firstname = $value['firstname'];
                        $date = $value['review_date'];
                        $review_text = $value['review_text'];
                        ?>
                        <p><strong><?php echo $firstname; ?>,<?php echo $date; ?> writes:</strong></p>
                        <p><?php echo $review_text; ?></p>

                    <?php } ?>
                </div>
            </div>        
            <div class="tab-pane detail_padding" id="tab">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
            </div>
        </div>

    </div>
</div>
<button type="button" class="top_arrow" id="top" onclick="gototop();"><object type="image/svg+xml" data="<?php echo $assets_url; ?>image/up-arrow-white.svg" height="15px" width="15px">
    </object></button>
<script type="text/javascript">
    jQuery(document).ready(function ($) {

        var jssor_1_SlideshowTransitions = [
            {$Duration: 800, x: 0.3, $During: {$Left: [0.3, 0.7]}, $Easing: {$Left: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, x: -0.3, $SlideOut: true, $Easing: {$Left: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, x: -0.3, $During: {$Left: [0.3, 0.7]}, $Easing: {$Left: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, x: 0.3, $SlideOut: true, $Easing: {$Left: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, y: 0.3, $During: {$Top: [0.3, 0.7]}, $Easing: {$Top: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, y: -0.3, $SlideOut: true, $Easing: {$Top: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, y: -0.3, $During: {$Top: [0.3, 0.7]}, $Easing: {$Top: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, y: 0.3, $SlideOut: true, $Easing: {$Top: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, x: 0.3, $Cols: 2, $During: {$Left: [0.3, 0.7]}, $ChessMode: {$Column: 3}, $Easing: {$Left: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, x: 0.3, $Cols: 2, $SlideOut: true, $ChessMode: {$Column: 3}, $Easing: {$Left: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, y: 0.3, $Rows: 2, $During: {$Top: [0.3, 0.7]}, $ChessMode: {$Row: 12}, $Easing: {$Top: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, y: 0.3, $Rows: 2, $SlideOut: true, $ChessMode: {$Row: 12}, $Easing: {$Top: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, y: 0.3, $Cols: 2, $During: {$Top: [0.3, 0.7]}, $ChessMode: {$Column: 12}, $Easing: {$Top: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, y: -0.3, $Cols: 2, $SlideOut: true, $ChessMode: {$Column: 12}, $Easing: {$Top: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, x: 0.3, $Rows: 2, $During: {$Left: [0.3, 0.7]}, $ChessMode: {$Row: 3}, $Easing: {$Left: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, x: -0.3, $Rows: 2, $SlideOut: true, $ChessMode: {$Row: 3}, $Easing: {$Left: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, x: 0.3, y: 0.3, $Cols: 2, $Rows: 2, $During: {$Left: [0.3, 0.7], $Top: [0.3, 0.7]}, $ChessMode: {$Column: 3, $Row: 12}, $Easing: {$Left: $Jease$.$InCubic, $Top: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, x: 0.3, y: 0.3, $Cols: 2, $Rows: 2, $During: {$Left: [0.3, 0.7], $Top: [0.3, 0.7]}, $SlideOut: true, $ChessMode: {$Column: 3, $Row: 12}, $Easing: {$Left: $Jease$.$InCubic, $Top: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, $Delay: 20, $Clip: 3, $Assembly: 260, $Easing: {$Clip: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, $Delay: 20, $Clip: 3, $SlideOut: true, $Assembly: 260, $Easing: {$Clip: $Jease$.$OutCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, $Delay: 20, $Clip: 12, $Assembly: 260, $Easing: {$Clip: $Jease$.$InCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2},
            {$Duration: 800, $Delay: 20, $Clip: 12, $SlideOut: true, $Assembly: 260, $Easing: {$Clip: $Jease$.$OutCubic, $Opacity: $Jease$.$Linear}, $Opacity: 2}
        ];

        var jssor_1_options = {
            $AutoPlay: 1,
            $Cols: 1,
            $Align: 0,
            $SlideshowOptions: {
                $Class: $JssorSlideshowRunner$,
                $Transitions: jssor_1_SlideshowTransitions,
                $TransitionsOrder: 1
            },
            $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
            },
            $ThumbnailNavigatorOptions: {
                $Class: $JssorThumbnailNavigator$,
                $Cols: 5,
                $SpacingX: 5,
                $SpacingY: 5,
                $Align: 390
            }
        };

        var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

        var MAX_WIDTH = 980;

        function ScaleSlider() {
            var containerElement = jssor_1_slider.$Elmt.parentNode;
            var containerWidth = containerElement.clientWidth;

            if (containerWidth) {

                var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                jssor_1_slider.$ScaleWidth(expectedWidth);
            } else {
                window.setTimeout(ScaleSlider, 30);
            }
        }

        ScaleSlider();

        $(window).bind("load", ScaleSlider);
        $(window).bind("resize", ScaleSlider);
        $(window).bind("orientationchange", ScaleSlider);
    });
</script>
</body>
</html>
