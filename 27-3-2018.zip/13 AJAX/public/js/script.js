function showLoginValidationError(msg) {
    $('.login_alert').removeClass('alert-success').addClass('alert-danger');
    $('.login_alert').css('display', 'block');
    $('.login_msg').text(msg);
    $('#login_form .form-group').addClass('validation-error');
}

function showLoingSuccess(msg) {
    $('.login_alert').removeClass('alert-danger').addClass('alert-success');
    $('.login_alert').css('display', 'block');
    $('.login_msg').text(msg);
    $('#login_form .form-group').removeClass('validation-error');
}

var pos = 1;
$("#position").change(function () {
    pos = $(this).val();
    $.ajax({
        url: site_url + 'product_display',
        type: "POST",
        data: {sort: pos},
        success: function (data) {
            $("#product_imgs").html(data);
            $("#more_product_btn").hide();
        }
    });
});

var limitIndex = 6;
$("#more_product_btn").click(function () {
    limitIndex += 6;
    ajaxIndex1();
});
function ajaxIndex1() {

    $.ajax({
        url: site_url + 'product_display',
        type: "POST",
        data: {limit: limitIndex},
        success: function (data) {
            $("#product_imgs").html(data);
        }
    });
}
ajaxIndex1();

var limitIndex1 = 8;
$("#home_more_product_btn").click(function () {
    limitIndex1 += 8;
    ajaxIndex();
});
function ajaxIndex() {
    $.ajax({
        url: site_url + 'home_product_display',
        type: "POST",
        data: {limit: limitIndex1},
        success: function (data) {
            $("#home_product_imgs").html(data);
        }
    });
}
ajaxIndex();

$('#email').on('focusout', function ()
{
    var email = $('#email').val();
    $.ajax({
        type: 'post',
        url: site_url + 'register/emailvalidate',
        data: {email: email},
        success: function (response) {
            console.log(response);
            $('#email_error').html(response);
        },
        error: function () {
            ajaxError();
        }
    });
});

$('#username').on('focusout', function ()
{
    var username = $('#username').val();
    $.ajax({
        type: 'post',
        url: site_url + 'register/uservalidate',
        data: {username: username},
        success: function (response) {
            if (response != '') {
                $('#username_error1').html(response);
            }
        },
        error: function () {
            ajaxError();
        }
    });
});

$("#login").submit(function (e) {
    e.preventDefault();
    var data = new FormData(this);
    $.ajax({
        type: 'post',
        url: site_url + 'login',
        dataType: 'json',
        data: data,
        processData: false,
        contentType: false,
        success: function (response) {
            if (response.status == 0) {
                showLoginValidationError(response.msg)
            } else if (response.status == 1) {
                showLoingSuccess(response.msg);
                location.reload();
            } else if (response.status == 2) {
                $('#password_error').text(response.msg);
                location.reload();
            }
        },
        error: function () {
            // $('#login_button').removeAttr('disabled');
            ajaxError();
        }
    });
});

$("#contact").click(function () {
    var name = $("#name").val();
    var email = $("#email").val();
    var subject = $("#subject").val();
    var message = $("#message").val();
    var flag = 0;
    if (name === "") {
        $("#name_error").text("Please enter your name");
        flag = 1;
    }
    if (email === "") {
        $("#email_error").text("Please enter your email");
        flag = 1;
    }
    if (subject === "") {
        $("#subject_error").text("Please enter subject");
        flag = 1;
    }
    if (message === "") {
        $("#message_error").text("Please enter message");
        flag = 1;
    }
    if (flag === 1) {
        return false;
    } else {
        return true;
    }
});

//$("#footer_news_button").click(function (){
//    var email = $("#footer_email").val();
//    var mail = /^[a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
//    
//    if (email === "") {
//        alert("Please enter email");
//        window.location.replace("/");
//    } else if (mail.test(email) === false) {
//        alert("You have to enter valid email");
//        window.location.replace("/");
//    }    
//});

$("#resetpassword").click(function (){
   var password = $("#newpassword").val();
   var repassword = $("#renewpassword").val();
   var pass = /^(?=(.*[A-Z]){2})(?=.*?[0-9])(?=.*?[!@#$%^&*])[a-zA-Z0-9!@#$%\^&\*]{4,}$/;
   var flag=0; 
   if (password == "") {
        $("#passsword_error").text("Please enter password");
        flag = 1;
    } else if (pass.test(password) === false) {
        $("#passsword_error").text("Password has atleast one number,two capital letter,atleast one symbol");
        flag = 1;
    } else {
        $("#passsword_error").text("");
    }
    
    if (repassword == "") {
        $("#repassword_error").text("Please enter password");
        flag = 1;
    } else if (pass.test(password) === false) {
        $("#repassword_error").text("Password has atleast one number,two capital letter,atleast one symbol");
        flag = 1;
    } 
    else if (repassword != password) {
        $("#repassword_error").text("Both password is not match");
        flag = 1;
    } else {
        $("#repassword_error").text("");
    }
    if (flag === 1) {
        return false;
    } else {
        return true;
    }
    
});

$("#register").click(function () {
    var username = $("#username").val();
    var password = $("#password").val();
    var confirm_password = $("#confirm_password").val();
    var firstname = $("#firstname").val();
    var lastname = $("#lastname").val();
    var email = $("#email").val();
    var phone = $("#phone").val();
    var mobile = $("#mobile").val();
    var $opt1 = $('#opt1');
    var $opt2 = $('#opt2');
    var $opt3 = $('#opt3');
    var $optoth = $('#optoth');
    var flag = 0;
    var user = /^[A-z]+$/;
    var pass = /^(?=(.*[A-Z]){2})(?=.*?[0-9])(?=.*?[!@#$%^&*])[a-zA-Z0-9!@#$%\^&\*]{4,}$/;
    var mail = /^[a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
    var first = /^[A-z]+$/;
    var mob = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
    var pho =/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;

    if (username === "") {
        $("#username_error1").text("Please enter username");
        flag = 1;
    } else if (username.length <= 7) {
        $("#username_error1").text("The lenght of username must be atleast eight digits");
        flag = 1;
    } else {
        $("#username_error1").text("");
    }

    if (password == "") {
        $("#passwordd_error").text("Please enter password");
        flag = 1;
    } else if (pass.test(password) === false) {
        $("#passwordd_error").text("Password has atleast one number,two capital letter,atleast one symbol");
        flag = 1;
    } else {
        $("#passwordd_error").text("");
    }

    if (firstname === "") {
        $("#firstname_error").text("Please enter firstname");
        flag = 1;
    } else if (first.test(firstname) === false) {
        $("#firstname_error").text("In firstname only allow alphabetic");
        flag = 1;
    } else {
        $("#firstname_error").text("");
    }

    if (mobile === "") {
        $("#mobile_error").text("Please enter mobile");
        flag = 1;
    } else if (mob.test(mobile) === false) {
        $("#mobile_error").text("You have to enter valid numbers");
        flag = 1;
    } else {
        $("#mobile_error").text("");
    }

    if (phone !== "") {
        if (pho.test(phone) === false) {
            $("#phone_error").text("Please enter valid phone numbers");
            flag = 1;
        } else {
            $("#phone_error").text("");
        }
    }

    if (lastname === "") {
        $("#lastname_error").text("Please enter lastname");
        flag = 1;
    } else {
        $("#lastname_error").text("");
    }

    if (confirm_password != password) {
        $("#confirm_password_error").text("Both password is not match");
        flag = 1;
    } else {
        $("#confirm_password_error").text("");
    }

    if (email === "") {
        $("#email_error").text("Please enter mobile");
        flag = 1;
    } else if (mail.test(email) === false) {
        $("#email_error").text("You have to enter valid email");
        flag = 1;
    } else {
        $("#email_error").text("");
    }

    if ($("#all").is(':checked') === false  && $("#option1").is(':checked') === false && $("#option2").is(':checked') === false && $("#option3").is(':checked') === false && $("#other").is(':checked') === false) {
        $("#checkbox_error").text("Please select your interests");
        flag = 1;
    } else {
        $("#checkbox_error").text("");
    }

    if ($("#genmale").is(':checked') === false && $("#genfemale").is(':checked') === false) {
        $("#gender_error").text("Please Select your gender");
        flag = 1;
    } else {
        $("#gender_error").text("");
    }

    if ($("#term").is(':checked') === false) {
        $("#term_error").text("Please select Terms & Conditions");
        flag = 1;
    } else {
        $("#term_error").text("");
    }

    if ($("#other").val() === "")
    {
        $("#other_error").text("Please enter you interests");
        flag = 1;
    } else {
        $("#other_error").text("")
    }

    if (flag === 1) {
        return false;
    } else {
        return true;
    }
    0
});

$("#profile").click(function () {

    var username = $("#username").val();
    var password = $("#password").val();
    var firstname = $("#firstname").val();
    var lastname = $("#lastname").val();
    var email = $("#email").val();
    var phone = $("#phone").val();
    var mobile = $("#mobile").val();
    var flag = 0;
    var user = /^[A-z]+$/;
    var pass = /^(?=(.*[A-Z]){2})(?=.*?[0-9])(?=.*?[!@#$%^&*])[a-zA-Z0-9!@#$%\^&\*]{4,}$/;
    var mail = /^[a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
    var first = /^[A-z]+$/;
    var mob = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
    var pho = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;

    if (firstname === "") {
        $("#firstname_error").text("Please enter firstname");
        flag = 1;
    } else if (first.test(firstname) === false) {
        $("#firstname_error").text("In firstname only allow alphabetic");
        flag = 1;
    } else {
        $("#firstname_error").text("");
    }

    if (mobile === "") {
        $("#mobile_error").text("Please enter mobile");
        flag = 1;
    } else if (mob.test(mobile) === false) {
        $("#mobile_error").text("You have to enter valid numbers");
        flag = 1;
    } else {
        $("#mobile_error").text("");
    }

    if (phone !== "") {
        if (pho.test(phone) === false) {
            $("#phone_error").text("Please enter valid phone numbers");
            flag = 1;
        } else {
            $("#phone_error").text("");
        }
    }

    if (lastname === "") {
        $("#lastname_error").text("Please enter lastname");
        flag = 1;
    } else {
        $("#lastname_error").text("");
    }

    if (email === "") {
        $("#email_error").text("Please enter email");
        flag = 1;
    } else if (mail.test(email) === false) {
        $("#email_error").text("You have to enter valid email");
        flag = 1;
    } else {
        $("#email_error").text("");
    }

    if ($("#all").is(':checked') === false  && $("#option1").is(':checked') === false && $("#option2").is(':checked') === false && $("#option3").is(':checked') === false && $("#other").is(':checked') === false) {
        $("#checkbox_error").text("Please select your interests");
        flag = 1;
    } else {
        $("#checkbox_error").text("");
    }

    if ($("#other").val() === "")
    {
        $("#other_error").text("Please enter you interests");
        flag = 1;
    } else {
        $("#other_error").text("");
    }

    if ($("#street").val() === "")
    {
        $("#street_error").text("Please enter your street");
        flag = 1;
    } else {
        $("#street_error").text("");
    }

    if ($("#city").val() === "")
    {
        $("#city_error").text("Please enter your city");
        flag = 1;
    } else {
        $("#city_error").text("");
    }

    if ($("#b_street").val() === "")
    {
        $("#b_street_error").text("Please enter your street");
        flag = 1;
    } else {
        $("#b_street_error").text("");
    }

    if ($("#b_city").val() === "")
    {
        $("#b_city_error").text("Please enter your city");
        flag = 1;
    } else {
        $("#b_city_error").text("");
    }

    if ($("#country").val() == "") {
        $("#country_error").text("Please select country");
        flag = 1;
    } else {
        $("#country_error").text("");
    }

    if ($("#state").val() == "") {
        $("#state_error").text("Please select state");
        flag = 1;
    } else {
        $("#state_error").text("");
    }

    if ($("#country2").val() == "") {
        $("#country2_error").text("Please select country");
        flag = 1;
    } else {
        $("#country2_error").text("");
    }

    if ($("#state2").val() == "") {
        $("#state2_error").text("Please select state");
        flag = 1;
    } else {
        $("#state2_error").text("");
    }

    if (flag === 1) {
        return false;
    } else {
        return true;
    }
});
/* 
 function profileValidate(){
 var pass=/^(?=(.*[A-Z]){2})(?=.*?[0-9])(?=.*?[!@#$%^&*])[a-zA-Z0-9!@#$%\^&\*]{4,}$/;
 var username = document.getElementById('username').value;
 var password = document.getElementById('password').value;
 var firstname = document.getElementById('firstname').value;
 var lastname = document.getElementById('lastname').value;
 var email= document.getElementById('email').value;
 var phone = document.getElementById('phone').value;
 var mobile = document.getElementById('mobile').value;
 var street=document.getElementById('street').value;
 var city=document.getElementById('city').value;
 var b_street=document.getElementById('b_street').value;
 var b_city=document.getElementById('b_city').value;
 
 var flag=0,shipError=0;
 
 if (username===""){
 document.getElementById("username_error").innerHTML = "Please enter username";
 
 flag=1;
 }
 else{document.getElementById("username_error").innerHTML = "";}
 
 if (username.length <= 8){
 document.getElementById("username_error").innerHTML = "The lenght of username must be atleast eight digits";
 
 flag=1;
 }
 else{document.getElementById("username_error").innerHTML = "";}
 
 if (( document.register.gender[0].checked ===false ) && ( document.register.gender[1].checked === false)) 
 {
 document.getElementById("gender_error").innerHTML = "Please select your gender";
 
 flag=1;
 }
 else{document.getElementById("gender_error").innerHTML = "";}
 
 if (password===""){
 document.getElementById("password_error").innerHTML = "Please enter password";
 
 flag=1;
 }
 else{document.getElementById("password_error").innerHTML = "";}
 
 if(pass.test(password)===false){
 document.getElementById("password_error").innerHTML = "Password has atleast one number,two capital letter,atleast one symbol ";
 
 flag=1;
 }
 else{document.getElementById("password_error").innerHTML = "";}
 
 if (email===""){
 document.getElementById("email_error").innerHTML = "Please enter email";
 
 flag=1;
 }  
 else{document.getElementById("email_error").innerHTML = "";}
 
 if (/^[a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,3}$/.test(email)=== false)
 {
 document.getElementById('email_error').innerHTML="Please enter valid email-id";  
 
 flag=1;
 }
 else{document.getElementById("email_error").innerHTML = "";}
 
 if (firstname===""){
 document.getElementById("firstname_error").innerHTML = "Please enter firstname";
 
 flag=1;
 }
 else{document.getElementById("firstname_error").innerHTML = "";}
 
 if(/^[A-z]+$/.test(firstname)===false){
 document.getElementById("firstname_error").innerHTML = "In firstname only allow alphabetic";
 
 flag=1;
 }
 else{document.getElementById("firstname_error").innerHTML = "";}
 
 if (lastname===""){
 document.getElementById("lastname_error").innerHTML = "Please enter lastname";
 
 flag=1;
 } 
 else{document.getElementById("lastname_error").innerHTML = "";}
 
 if (mobile===""){
 document.getElementById("mobile_error").innerHTML = "Please enter mobile";
 
 flag=1;
 }
 else{document.getElementById("mobile_error").innerHTML = "";}
 
 if (/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/.test(mobile)===false){
 document.getElementById("mobile_error").innerHTML = "You have to enter valid numbers";
 
 flag=1;
 }
 else{document.getElementById("mobile_error").innerHTML = "";}
 
 if (phone!==""){
 if(/^[0-9]*$/.test(phone)===false){
 document.getElementById("phone_error").innerHTML = "Please enter only numbers";
 
 flag=1;
 }
 else{document.getElementById("phone_error").innerHTML = "";}
 }
 
 if (document.getElementById('all').checked === false && document.getElementById('option1').checked === false && document.getElementById('option2').checked === false && document.getElementById('option2').checked === false && document.getElementById('other').checked === false) 
 {
 document.getElementById("checkbox_error").innerHTML = "Please select your interests";
 
 flag=1;
 }else{document.getElementById("checkbox_error").innerHTML = "";}
 
 
 if (street===""){
 document.getElementById("street_error").innerHTML = "Please enter your street";
 
 flag=1;
 shipError=1;
 }else{document.getElementById("street_error").innerHTML = "";}
 
 if (city===""){
 document.getElementById("city_error").innerHTML = "Please enter your city";
 
 flag=1;
 shipError=1;
 }else{document.getElementById("city_error").innerHTML = "";}
 
 if (document.getElementById("country").selectedIndex=== 0) {
 
 document.getElementById("country_error").innerHTML = "Please select country";
 flag=1;
 shipError=1;
 } else {
 document.getElementById("country_error").innerHTML = "";
 }
 
 if (document.getElementById("state").selectedIndex === 0) {
 
 document.getElementById("state_error").innerHTML = "Please select state";
 flag=1;
 shipError=1;
 } else {
 document.getElementById("state_error").innerHTML = "";
 }
 
 if (b_street===""){
 document.getElementById("b_street_error").innerHTML = "Please enter your street";
 
 flag=1;
 shipError=2;
 }else{document.getElementById("b_street_error").innerHTML = "";}
 
 if (b_city===""){
 document.getElementById("b_city_error").innerHTML = "Please enter your city";
 
 flag=1;
 shipError=2;
 }else{document.getElementById("b_city_error").innerHTML = "";}
 
 if (document.getElementById("country2").selectedIndex=== 0) {
 
 document.getElementById("country2_error").innerHTML = "Please select country";
 flag=1;
 shipError=2;
 } else {
 document.getElementById("country2_error").innerHTML = "";
 }
 
 if (document.getElementById("state2").selectedIndex === 0) {
 
 document.getElementById("state2_error").innerHTML = "Please select state";
 flag=1;
 shipError=2;
 } else {
 document.getElementById("state2_error").innerHTML = "";
 }
 if(other===""){
 document.getElementById("other_error").innerHTML = "Please enter you interests";
 flag=1;
 }
 else{
 document.getElementById("other_error").innerHTML = "";
 }
 //    if(shipError===1){
 //        $("#add").slideDown();
 //    }else if(shipError===2){
 //        $("#add2").slideDown();
 //        $("#add").slideDown();
 //    }
 if(flag===1){
 return false;
 }
 }
 
 
 function registerValidate(){
 var pass=/^(?=(.*[A-Z]){2})(?=.*?[0-9])(?=.*?[!@#$%^&*])[a-zA-Z0-9!@#$%\^&\*]{4,}$/;
 var username = document.getElementById('username').value;
 var password = document.getElementById('password').value;
 var confirm_password=document.getElementById('confirm_password').value;
 var firstname = document.getElementById('firstname').value;
 var lastname = document.getElementById('lastname').value;
 var email= document.getElementById('email').value;
 var phone = document.getElementById('phone').value;
 var mobile = document.getElementById('mobile').value;
 var flag=0;
 if(other===""){
 document.getElementById("other_error").innerHTML = "Please enter you interests";
 flag=1;
 }
 else{
 document.getElementById("other_error").innerHTML = "";
 }
 if (username===""){
 document.getElementById("username_error").innerHTML = "Please enter username";   
 flag=1;
 }
 else{document.getElementById("username_error").innerHTML = "";}
 if(/^[A-z]+$/.test(username)===false){
 document.getElementById("username_error").innerHTML = "In firstname only allow alphabetic";
 
 flag=1;
 }
 else{document.getElementById("username_error").innerHTML = "";}
 if (username.length <= 8){
 document.getElementById("username_error").innerHTML = "The lenght of username must be atleast eight digits";
 
 flag=1;
 }
 else{document.getElementById("username_error").innerHTML = "";}
 
 if (( document.register.gender[0].checked ===false ) && ( document.register.gender[1].checked === false)) 
 {
 document.getElementById("gender_error").innerHTML = "Please Select your gender";
 
 flag=1;
 }
 else{document.getElementById("gender_error").innerHTML = "";}
 
 if (password===""){
 document.getElementById("password_error").innerHTML = "Please enter password";
 
 flag=1;
 }
 else{document.getElementById("password_error").innerHTML = "";}
 
 if(pass.test(password)===false){
 document.getElementById("password_error").innerHTML = "Password has atleast one number,two capital letter,atleast one symbol ";
 
 flag=1;
 }
 else{document.getElementById("password_error").innerHTML = "";}
 if((confirm_password===password)===false){
 document.getElementById("comfirm_password_error").innerHTML = "Both password is not match";
 flag=1;
 }
 else{
 document.getElementById("comfirm_password_error").innerHTML = "";
 }
 if (email===""){
 document.getElementById("email_error").innerHTML = "Please enter email";
 
 flag=1;
 }  
 else{document.getElementById("email_error").innerHTML = "";}
 
 if (/^[a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,3}$/.test(email)=== false)
 {
 document.getElementById('email_error').innerHTML="please enter valid email-id";  
 
 flag=1;
 }
 else{document.getElementById("email_error").innerHTML = "";}
 
 if (firstname===""){
 document.getElementById("firstname_error").innerHTML = "Please enter firstname";
 
 flag=1;
 }
 else{document.getElementById("firstname_error").innerHTML = "";}
 
 if(/^[A-z]+$/.test(firstname)===false){
 document.getElementById("firstname_error").innerHTML = "In firstname only allow alphabetic";
 
 flag=1;
 }
 else{document.getElementById("firstname_error").innerHTML = "";}
 
 if (lastname===""){
 document.getElementById("lastname_error").innerHTML = "Please enter lastname";
 
 flag=1;
 } 
 else{document.getElementById("lastname_error").innerHTML = "";}
 
 if (mobile===""){
 document.getElementById("mobile_error").innerHTML = "Please enter mobile";
 
 flag=1;
 }
 else{document.getElementById("mobile_error").innerHTML = "";}
 
 if (/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/.test(mobile)===false){
 document.getElementById("mobile_error").innerHTML = "You have to enter valid numbers";
 flag=1;
 }
 else{document.getElementById("mobile_error").innerHTML = "";}
 
 if (phone!==""){
 if(/^[0-9]*$/.test(phone)===false){
 document.getElementById("phone_error").innerHTML = "Please enter only numbers";
 flag=1;
 }
 else{document.getElementById("phone_error").innerHTML = "";}
 }
 
 if (document.getElementById('all').checked === false && document.getElementById('option1').checked === false && document.getElementById('option2').checked === false && document.getElementById('option2').checked === false && document.getElementById('other').checked === false) 
 {
 document.getElementById("checkbox_error").innerHTML = "Please select your interests";
 flag=1;
 }else{document.getElementById("checkbox_error").innerHTML = "";}
 
 if (document.getElementById('term').checked === false){
 document.getElementById("term_error").innerHTML = "Please select Terms & Conditions";
 flag=1;
 }else{document.getElementById("term_error").innerHTML = "";}
 
 if(flag===1){
 return false;
 }
 }
 */
function selectAll() {
    if ($("#all").prop('checked') === true) {
        $('#all').prop('checked', true);
        $('#option1').prop('checked', true);
        $('#option2').prop('checked', true);
        $('#option3').prop('checked', true);
    } else {
        $('#all').prop('checked', false);
        $('#option1').prop('checked', false);
        $('#option2').prop('checked', false);
        $('#option3').prop('checked', false);
    }
}

function otherClick() {
    if (document.getElementById('option1').checked === true && document.getElementById('option2').checked === true && document.getElementById('option3').checked === true)
    {
        document.getElementById('all').checked = true;
    } else {
        document.getElementById('all').checked = false;
    }
}

function textBoxhide() {
    if (document.getElementById('other').checked === true) {
        document.getElementById('togglee').style.visibility = 'visible';
        var other = document.getElementById('togglee').value;
        if (other === "") {
            document.getElementById("other_error").innerHTML = "Please enter you interests";
            flag = 1;
        }
        if (other !== "") {
            document.getElementById("other_error").innerHTML = "";
        }
    }

    if (document.getElementById('other').checked === false) {
        document.getElementById('togglee').style.visibility = 'hidden';
        document.getElementById("other_error").innerHTML = "";
    }

}

function loginValidate() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var flag = 0;
    if (username === "") {
        document.getElementById('username_error').innerHTML = "Please enter username";

        flag = 1;
    } else {
        document.getElementById('username_error').innerHTML = "";
    }
    if (password === "") {
        document.getElementById('password_error').innerHTML = "Please enter password";

        flag = 1;
    }
    if (flag === 1) {
        return false;
    }
}

function clear() {
    
    
    $("#username_error").text("");
    $("#password_error").text("");
    $("#gender_error").text("");
    $("#email_error").text("");
    $("#firstname_error").text("");
    $("#lastname_error").text("");
    $("#moblie_error").text("");
    $("#phone_error").text("");
    $("#checkbox_error").text("");
    $("#term_error").text("");
    $("register").reset();
    
    
}

//var total;
//function total_dropdown() {
//    var qty = document.getElementById('qty').value;
//    var price = document.getElementById('price').innerHTML;
//    total = qty * 120;
//    document.getElementById('price').innerHTML = total;
//}

function addcart() {
    var price = document.getElementById('price').innerHTML;
    confirm("Are you sure you want to purchase this product?\n Your total bill amount is $ " + price + ".00");
}

function same_address() {
    if (document.getElementById("sameaddress").checked === true) {
        var street = document.getElementById('street').value;
        var city = document.getElementById('city').value;
        var country = document.getElementById('country').value;
        var state = document.getElementById('state').value;
        document.getElementById('b_street').value = street;
        document.getElementById('b_city').value = city;
        document.getElementById('country2').value = country;
        var selectedCountryIndex = document.getElementById("country2").selectedIndex;
        document.getElementById('state2').value = state;
    } else {
        var street = document.getElementById('b_street').value = "";
        var city = document.getElementById('b_city').value = "";
        var country = document.getElementById('country2').value = "";
        var state = document.getElementById('state2').value = "";
    }
}
$("#sameaddress").click(function () {
    var check1 = document.getElementById("sameaddress").checked;
    if (check1 == true) {
        var $options = $("#state > option").clone();
        $('#state2').empty();
        $('#state2').append($options);
        $('#state2').val($('#state').val());

    } else {
        $('#state2').empty();
        $('#state2').val("");

    }
})
var products = [
    ['image/cart-img01.jpg', 'US Polo Assn FullSleeve Plain T-Shirts for Men', 'Blue', 'M', 'image/edit-dark.svg', '$222', '1', '$222', 'image/cross-dark.svg'],
    ['image/cart-img01.jpg', 'US Polo Assn FullSleeve Plain T-Shirts for Men', 'Blue', 'M', 'image/edit-dark.svg', '$222', '1', '$222', 'image/cross-dark.svg'],
    ['image/cart-img01.jpg', 'US Polo Assn FullSleeve Plain T-Shirts for Men', 'Blue', 'M', 'image/edit-dark.svg', '$222', '1', '$222', 'image/cross-dark.svg'],
    ['image/cart-img01.jpg', 'US Polo Assn FullSleeve Plain T-Shirts for Men', 'Blue', 'M', 'image/edit-dark.svg', '$222', '1', '$222', 'image/cross-dark.svg']
];

function updatesubtotal() {
    for (var i = 0; i < products.length; i++) {
        row = "<tr>";
        row += "<td><img src='" + products[i][0] + "'></td>";
        row += "<td>" + products[i][1] + "<br/><b>Color</b><br/>" + products[i][2] + "<br/><b>Size</b><br/>" + products[i][3] + "</td>";
        row += "<td><object type='image/svg+xml' class='size_icon' data='" + products[i][4] + "'></object></td>";
        row += "<td class='Cart_price_color'>" + products[i][5] + "</td>";
        row += "<td class='cart_table_border1'>" + products[i][6] + "</td>";
        row += "<td class='Cart_price_color'>" + products[i][7] + "</td>";
        row += "<td onclick=''><object type='image/svg+xml' class='size_icon' data='" + products[i][8] + "'></object></td>";
        row += "</tr>";
        $("#product").append(row);
    }
    row = "<tr class='cart_table_header'>";
    row += "<td colspan='3'><button type='button' class='btn btn-default reg_clear cart_update_button'>Continue Shopping</button></td>";
    row += "<td colspan='5' class='cart_table_footer'><button type='button' class='btn btn-default reg_clear1 cart_update_button'>Clear Shopping Cart</button><button type='button' class='btn btn-default reg_clear1 cart_update_button'>Update Shopping Cart</button></td>";

    row += "</tr>";
    $("#product").append(row);
}

$(window).scroll(function () {
    var scrol = $(window).scrollTop();
    if (scrol > 0) {
        $('#top').show();
    } else {
        $('#top').hide();
    }
});
function gototop() {
    $('#top').click(function () {
        $('html, body').animate({scrollTop: 0}, 800);
        return false;
    });
}

$('.search').click(function () {
    $('.searchtext').toggleClass('expanded');
});

$(".cart").click(function (event) {
    event.stopPropagation();
    $("#cart").slideToggle();
    $('html, body').animate({scrollTop: 0}, 800);
});


//$(document).click(function () {
//    $("#cart").hide();
//});

$("#country").change(function ()
{

    var id = $(this).val();
    var dataString = 'id=' + id;


    $.ajax
            ({
                type: "POST",
                url: site_url + "profile/state_shoping",
                data: dataString,
                cache: false,
                success: function (data)
                {

                    $("#state").empty();
                    var state = $.parseJSON(data);
                    $.each(state, function (i, val) {
                        $("#state").append("<option value='" + val.id + "'>" + val.name + "</option>");
                    });
                },
                error: function () {
                    alert("error");
                }
            });
});

$("#country2").change(function ()
{

    var id = $(this).val();
    var dataString = 'id=' + id;


    $.ajax
            ({
                type: "POST",
                url: site_url + "profile/state_biling",
                data: dataString,
                cache: false,
                success: function (data)
                {

                    $("#state2").empty();
                    var state = $.parseJSON(data);
                    $.each(state, function (i, val) {
                        $("#state2").append("<option value='" + val.id + "'>" + val.name + "</option>");
                    });
                },
                error: function () {
                    alert("error");
                }
            });
});

$("#wishlist").click(function () {
    var id = $("#itemid").val();
    var dataString = 'id=' + id;
    $.ajax(
            {
                url: site_url + "product/addwislist",
                type: 'POST',
                data: dataString,
                success: function (response) {
                    var status = JSON.stringify(response);
                    var result = JSON.parse(status);
                    if (result == 3) {
                        alert("You Have To Login To Add Wishlist");
                    } else if (result != 1) {
                        alert("Alredy Added To Wishlist");
                    } else {
                        $("#Wishlistalert").show();
                        $('html, body').animate({scrollTop: 0}, 800);
                    }
                },
                error: function (response) {
                    alert("Alredy Added To Wishlist");
                }
            })
});

$('input[name=rating]').click(function () {
    $("#rating").val(this.value);
});

$("#reviewbtn").click(function () {
    var rating = $("#rating").val();
    var coment = $("#comment").val();
    var itemid = $("#itemid").val();
    var dataString = 'rating=' + rating + '&coment=' + coment + '&itemid=' + itemid;
    $.ajax({
        type: 'POST',
        url: site_url + "product/addreview",
        data: dataString,
        /*  dataType: 'json',
         encode:true,*/
        success: function (response) {
            var ResponseArray = response.split("-");
            if (ResponseArray[0] == 1) {
                alert("Please Log In To Add Review.");
            }
            var review = $.parseJSON(response);
            if (review.status == 1) {
                alert("You Have Already Add Review On This Product");
            } else {
                $("#output").prepend("<p><strong>" + review.firstname + "," + review.date + " " + "writes</strong></p><p>" + coment + "</p>");
            }
        },
        error: function (response) {
            alert("Error");
        }
    });
});

var qty = 0;
var size = 0;
$("#qty").change(function () {
    qty = $(this).val();
});
$("#size").change(function () {
    size = $(this).val();

});

$("#addtocart1").click(function () {
    var id = $("#iditem").val();

    if (qty == 0 || size == 0) {
        window.alert("Select Qty Or Size");
        exit();
    }
    var dataString = 'id=' + id + '&size=' + size + ' &qty=' + qty;

    $.ajax({
        type: 'POST',
        url: site_url + 'Cart/addtocart',
        data: dataString,
        /* dataType : 'json',
         encode : true,*/
        success: function (response) {

            var ResponseArray = response.split("-");
            if (ResponseArray[0] == 1) {
                window.alert("Your Item Is Successfully Added To Cart");
                window.location.replace(ResponseArray[1]);
                
            } else {
                // alert('Please log in to add product into cart.');
                window.location.replace(ResponseArray[1]);
            }

            //alert(response);
            // alert(JSON.stringify(response));
            //$('.testtable').load(site_url+" .testbody");
            //location.reload();
            // window.location = site_url+"home";
        },
        error: function (response) {
            console.log(response);
        },
    });
});
$("#updatecart").click(function () {
    var id = document.getElementsByName("id");
    var qty = document.getElementsByName("qty1");

    var qtyArray = new Array();
    for (var i = 0; i < qty.length; i++)
    {
        qtyArray[i] = {'id': id[i].value, 'qty': qty[i].value};

    }
    $.ajax({
        type: 'POST',
        url: site_url + 'cart/updateCart1',
        data: {result: JSON.stringify(qtyArray)},
        success: function (response) {
            location.reload();
        },
        error: function (response) {
            console.log(response);
        }
    });
});
function updatetotal() {

    var qty = document.getElementsByName("qty1");
    var price = document.getElementsByName("price1");
    var no = "/^[0-9]*$/";
    var total = 0;
    for (var i = 0; i < price.length; i++) {
        if (qty[i].value === "") {
            alert("Please Enter Qty");
        } else if (qty[i].value.length > 2) {
            alert("Please Enter Only 2 Digit");
        } else if (/^[0-9]*$/.test(qty[i].value) === false) {
            alert("Please Enter Only Number");
        }
        var price1 = price[i].textContent
        var price2 = price1.substr(1, price1.length);
        total = parseInt(price2);
        document.getElementsByName("subtotal1")[i].innerHTML = "$" + price2 * qty[i].value + ".00";
    }
}
var minVal;
var maxVal;
$("#slider-range").mouseup(function () {
    minVal = $("#amount1").val();
    maxVal = $("#amount2").val();
});
$(function () {
    var minValue = parseInt($("#amount1").val());
    var maxValue = parseInt($("#amount2").val());
    $("#slider-range").slider({
        range: true,
        min: minValue,
        max: maxValue,
        values: [minValue, maxValue],
        slide: function (event, ui) {
            $("#amount1").val(ui.values[ 0 ]);
            $("#amount2").val(ui.values[ 1 ]);
        },
        stop: function (event, ui) {
            $("#slider-range").trigger("change");
        }
    });
    $("#amount1").val($("#slider-range").slider("values", 0));
    $("#amount2").val($("#slider-range").slider("values", 1));
});

$('.size,.color,#position_filter,#slider-range').change(function (e) {
    var selectedSize = $(".size:checked").length;
    var selectedColor = $(".color:checked").length;
    var selectedSort = parseInt(($("#position_filter").val()));
    var minValue = parseInt($("#amount1").val());
    var maxValue = parseInt($("#amount2").val());
    if ($(".color:checked")) {
        //$(".color:checked").style.opacity = 0.5;
    }
    if (selectedSize != 0) {
        var sizeId = '[';
        $.each($(".size:checked"), function (index, element) {
            sizeId += '{\"id\":' + '\"' + $(this).val() + '\"}';
            if (index != selectedSize - 1) {
                sizeId += ',';
            }
        });
        sizeId += ']';
    } else {
        var sizeId = 0;
    }
    if (selectedColor != 0) {
        var colorId = '[';
        $.each($(".color:checked"), function (index, element) {
            colorId += '{\"id\":' + '\"' + $(this).val() + '\"}';
            if (index != selectedColor - 1) {
                colorId += ',';
            }
        });
        colorId += ']';
    } else {
        var colorId = 0;
    }

    $.ajax({
        type: 'POST',
        url: site_url + 'product/filterProducts',
        data: "productSize=" + sizeId + "&productColor=" + colorId + "&productSort=" + selectedSort + "&minVal=" + minValue + "&maxVal=" + maxValue,

        beforeSend: function () {
            $("html, body").animate({
                scrollTop: 200
            }, 600);
            $("#product_imgs").hide();
            $("#more_product_btn").hide();
            $("#sort_view").hide();
            $("#sort_view_filter").show();
            $("#no_more_data").hide();
            $("#loading_image").show();
        },
        success: function (response) {
            if ($("#loading_image").show() === true) {
                $("#sort_view_filter").hide();
            }
            if (response == 1) {
                setTimeout(function () {
                    $("#loading_image").hide();
                    $("#product_imgs").hide();
                    $("#no_more_data").show();
                    $("#notAvailableAlert").show();
                }, 300);
            } else {
                setTimeout(function () {
                    $("#notAvailableAlert").hide();
                    $("#loginAlert").hide();
                    $("#product_imgs").show();
                    $("#loading_image").hide();
                    document.getElementById("product_imgs").innerHTML = response;
                }, 500);
            }
        },
        error: function (response) {
            console.log(response);
        }
    });
    // }
});
